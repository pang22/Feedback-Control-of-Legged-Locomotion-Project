clc;clear;close all
% qy = 0 *pi/180;
% qx = 0*pi/180;
% qSTH_R = 0 *pi/180; %something is wrong
% qSTH_P = 180 *pi/180;
% 
% qSWH_R = 0 *pi/180;
% qSWH_P = 180 *pi/180;
% 
% q = [qy;... torso row angle
%      qx;... torso pitch angle
%      qSTH_R;...stance hip roll angle
%      qSTH_P;...stance hip pitch angle
%      qSWH_R;...swing hip roll angle
%      qSWH_P];...swing hip pitch angle
     
% Initial Condition from Ben Beiter
%  q = [-0.22707; 0.33466; 0.38652; -0.23124; 0.41071; 0.33103];
% %  q = [-0.22707; 0.33466; -0.23124; 0.38652; -0.33103; -0.41071];
%  q_deg = q * 180 / pi;
%  display(q_deg)

% IC from Philip Hancock
% q = [0.4879;...
%      -0.1442;...
%      0.3699;...
%      pi-2.8005;...
%      0.0637;...
%      pi-2.8412];
% x = 3; y  = 2; z = 1;

% Joeseph's IC
q = [0.0554404748398413;...
    -0.429345617288958;...
    0.0452981444722582;...
    3.26486885286347;...
    0.226622971132814;...
    3.71651071638615];

 q_deg = q * 180 / pi;
 display(q_deg)

% q = zeros(1,6);
FK_output = FK_hw31(q);
pcm = pcm_hw31(q);
p0 = FK_output(:,1);
pcmT = FK_output(:,2);
pHst = FK_output(:,3);
pHsw = FK_output(:,4);
pcmST = FK_output(:,5);
pcmSW = FK_output(:,6);
p1 = FK_output(:,7);
p2 = FK_output(:,8);

figure
plot3([p0(1);pcmT(1)],[p0(2);pcmT(2)],[p0(3);pcmT(3)],'r','linewidth',6)
hold on
plot3([p0(1);pHst(1)],[p0(2);pHst(2)],[p0(3);pHst(3)],'g','linewidth',6)%stance hip
plot3([p0(1);pHsw(1)],[p0(2);pHsw(2)],[p0(3);pHsw(3)],'b','linewidth',6)%swing hip
plot3([pHst(1);p1(1)],[pHst(2);p1(2)],[pHst(3);p1(3)],'m','linewidth',6)%stance leg
plot3([pHsw(1);p2(1)],[pHsw(2);p2(2)],[pHsw(3);p2(3)],'c','linewidth',6)%swing leg

scatter3(pcmST(1),pcmST(2),pcmST(3),100,'filled','MarkerFaceColor','y')
scatter3(pcmSW(1),pcmSW(2),pcmSW(3),100,'filled','MarkerFaceColor','y')
scatter3(pcmT(1),pcmT(2),pcmT(3),100,'filled','MarkerFaceColor','y')
scatter3(pcm(1),pcm(2),pcm(3),100,'filled','MarkerFaceColor','k')
legend('Torso','Stance hip','Swing hip','stance leg','swing leg','stance leg CoM','swing leg CoM','Torso CoM')

x1 = -0.5; x2 = 0.5; y1 = -0.5; y2 = 0.5;
plot_xyground(x1,x2,y1,y2)

display(p2(3))
view(100,20)
grid on
xlabel('X (m)')
ylabel('Y (m)')
zlabel('Z (m)')
axis equal
hold off