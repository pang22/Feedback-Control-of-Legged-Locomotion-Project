function plot_cylinder(height,radius,R,center,color_txt)

[x,y,z] = cylinder;
[m,n]   = size(x);
x = radius * x;
y = radius * y;
z = height * z;

pos_down = [x(1,:); y(1,:); z(1,:)];
pos_up   = [x(2,:); y(2,:); z(2,:)];

pos_down_temp = R * pos_down + [center(1)*ones(1,n); center(2)*ones(1,n); center(3)*ones(1,n)]; 
pos_up_temp   = R * pos_up + [center(1)*ones(1,n); center(2)*ones(1,n); center(3)*ones(1,n)]; 

x = [pos_down_temp(1,:); pos_up_temp(1,:)];
y = [pos_down_temp(2,:); pos_up_temp(2,:)];
z = [pos_down_temp(3,:); pos_up_temp(3,:)];

surf(x,y,z,'FaceColor',color_txt,'EdgeColor','none')

end

