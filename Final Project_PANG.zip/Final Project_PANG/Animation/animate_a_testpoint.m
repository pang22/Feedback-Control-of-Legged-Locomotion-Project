
% Leg
leg = 0; % 0 for the right stance and 1 for the left stance 

% Make qs in degs
qz  = 0;
qy  = 0;
qx  = -5;

q4R = 0;
q3R = 200;
q2R = 30;

q4L = 0;
q3L = 220;
q2L = 30;

qs = pi/180*[qz; qy; qx; q2R; q3R; q4R; q2L; q3L; q4L];

% Lift map
if leg==0 % right stance
    [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Right(qs);
else % left stance
    [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Left(qs);
end % end of if

% Extended coordinates
q  = [p0; qs];

MAKE_FILM   = 0;
shadowing   = 0;
robot_view  = 'iso';
slow_motion = 0;
time        = 0;
animate_robot_walking(MAKE_FILM,shadowing,robot_view,slow_motion,time,q,pcm,p0,p0T,pHR,p1R,p2R,p3R,pHL,p1L,p2L,p3L);