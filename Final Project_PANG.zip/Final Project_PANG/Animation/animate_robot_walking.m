function animate_robot_walking(MAKE_FILM,shadowing,robot_view,slow_motion,time,Q,Pcm,P0,P0T,PHR,P1R,P2R,P3R,PHL,P1L,P2L,P3L)

avifile_name = 'Optim_02_Period_p5s';
h = figure('Name',avifile_name);%,'Position',[400 200 800 680]);
set(h,'Renderer','zbuffer')

if(MAKE_FILM)
    mov = VideoWriter(['SimulationAnimations\',avifile_name]); %,'MPEG-4');
    %mov.FrameRate = 30; % Real time animation
    open(mov);
end % end of if

if shadowing
    temp = 10;
else
    temp = 1;
end; % end of if

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Added by Kaveh for Rough Ground Walking
%
% [Y_event_history_corrected,Z_event_history_corrected] = find_change_in_height(robot.m_Solution.Event_Points(2,:),robot.m_Solution.Event_Points(3,:));
% %X_event_history_corrected = robot.m_Solution.Event_Points(1,:);
x_ground = [-1 1];
y_ground = [0 100];
m_ground = length(y_ground);
n_ground = length(x_ground);
z_ground = zeros(m_ground,n_ground);
% for i=1:m_ground
%     z_ground(i,:) = ground_pulse_function(y_ground(i),Y_event_history_corrected,Z_event_history_corrected)*ones(1,n_ground);
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[~,n] = size(Q);

for i=1:temp:n
    
    %pause
    q   = Q(:,i);
    pcm = Pcm(:,i);
    p0  = P0(:,i);
    p0T = P0T(:,i);
    
    pHR = PHR(:,i);
    p1R = P1R(:,i);
    p2R = P2R(:,i);
    p3R = P3R(:,i);

    pHL = PHL(:,i);
    p1L = P1L(:,i);
    p2L = P2L(:,i);
    p3L = P3L(:,i);
    
    xr  = [p1R(1) p2R(1) p3R(1); p2R(1) p3R(1) pHR(1)];
    xl  = [p1L(1) p2L(1) p3L(1); p2L(1) p3L(1) pHL(1)];
    xhR = [p0(1); pHR(1)];
    xhL = [p0(1); pHL(1)];
    xt  = [p0T(1); (pHR(1)+pHL(1))/2];
    
    yr  = [p1R(2) p2R(2) p3R(2); p2R(2) p3R(2) pHR(2)];
    yl  = [p1L(2) p2L(2) p3L(2); p2L(2) p3L(2) pHL(2)];
    yhR = [p0(2); pHR(2)];
    yhL = [p0(2); pHL(2)];
    yt  = [p0T(2); (pHR(2)+pHL(2))/2];
    
    zr  = [p1R(3) p2R(3) p3R(3); p2R(3) p3R(3) pHR(3)];
    zl  = [p1L(3) p2L(3) p3L(3); p2L(3) p3L(3) pHL(3)];
    zhR = [p0(3); pHR(3)];
    zhL = [p0(3); pHL(3)];
    zt  = [p0T(3); (pHR(3)+pHL(3))/2];
    
    clf;
    %axis off
    
    line(xr,yr,zr,'LineWidth',3,'Color','r');
    line(xl,yl,zl,'LineWidth',3,'Color','r');
    line(xhR,yhR,zhR,'LineWidth',2,'Color','r');
    line(xhL,yhL,zhL,'LineWidth',2,'Color','r');
    line(xt,yt,zt,'LineWidth',3,'Color','r');
    
    hold on
    plot3(p1R(1),p1R(2),p1R(3),'bo')
    plot3(p1L(1),p1L(2),p1L(3),'bo')
    
    if 1
        % Torso
        center_torso = 1/4*(p0+3*p0T);
        torso_x_length = 0.3;
        torso_y_length = 0.4;
        torso_z_length = 0.4;
        R_torso = rotation_matrix_MARLO(0,0,q(3));
        %cube_patching(torso_x_length,torso_y_length,torso_z_length,R_torso,center_torso)
        
        % Motors
        hip_length   = 0.05;
        motor_radius = 0.05;
        R_righthip = R_torso * rotation_about_y(pi/2);
        R_lefthip = R_torso * rotation_about_y(-pi/2);
        plot_sphere(motor_radius,pHR)
        plot_sphere(motor_radius,pHL)
        %plot_cylinder(hip_length,motor_radius,R_righthip,pHR)
        %plot_cylinder(hip_length,motor_radius,R_lefthip,pHL);
        
        % Joints
        joint_length   = 0.05;
        joint_radius = 0.02;
        %plot_cylinder(joint_length,joint_radius,R_righthip,p2R)
        %plot_cylinder(joint_length,joint_radius,R_lefthip,p2L);
        plot_cylinder(joint_length,joint_radius,R_righthip,p3R)
        plot_cylinder(joint_length,joint_radius,R_lefthip,p3L);
        %plot_cylinder(joint_length,joint_radius,R_righthip,p1R)
        %plot_cylinder(joint_length,joint_radius,R_lefthip,p1L);
        %plot_cylinder(joint_length,joint_radius,R_righthip,p4R)
        %plot_cylinder(joint_length,joint_radius,R_lefthip,p4L);
    end
    
    % Added by Kaveh to plot the ground
    %plot3(X_event_history(:,9),Y_event_history(:,9),Z_event_history(:,9))
    %     hold on
    hground = surf(x_ground,y_ground,z_ground,'FaceColor','interp');
    %     %shading interp
    %     %colormap(0.8*bone+0.2)
    colormap(0.8*spring+0.2)
    %     switch robot.animate_opt.view.m_value(1)
    %         case 270
    %             set(hground,'LineWidth',3)
    %     end
    %camlight;
    light('Position',[1 1 3],'Style','infinite')
    %lightangle(180,45)
    lighting flat
    %axis off
    axis([-1 1 -1 1 -0.25 1.75]);
    xlim([pcm(1)-1 pcm(1)+1]);
    ylim([pcm(2)-1 pcm(2)+1]);
    xlabel '(m)';ylabel '(m)';zlabel '(m)';
    switch robot_view
        case 'front'
            view([180 0])
        case 'side'
            view([90 0])
        case 'iso'
            view([135 15])
        case 'top'
            view([180 90])
    end % end of switch
    grid on;
    title(sprintf('time = %6.3f seconds',time(i)));
    
    %camorbit(0.001*i,0,'camera')
    
    if(MAKE_FILM)
        F = getframe(gcf);
        %F = im2frame(gcf);
        writeVideo(mov,F);
        %F = getframe(gcf);
        %mov = addframe(mov,gcf);
    end % end of if
    drawnow;
    
    switch slow_motion
        case 1
            pause(1);
        otherwise
    end
    % end of switch(.)
    
    %     if strcmp(reply,'Y')
    %         fprintf(coords,'%d  %d  %d  %d  %d  %d  %d  %d  %d  %d  %d  %d \r\n',convang(robot.m_Solution.xState_Solution(i,robot.QTZ),'rad','deg'),...
    %             convang(robot.m_Solution.xState_Solution(i,robot.QTY),'rad','deg'),convang(robot.m_Solution.xState_Solution(i,robot.QTX),'rad','deg'),...
    %             pcmT',convang(robot.m_Solution.xState_Solution(i,robot.Q3R),'rad','deg'),convang(robot.m_Solution.xState_Solution(i,robot.Q3L),'rad','deg'),...
    %             convang(robot.m_Solution.xState_Solution(i,robot.Q1R),'rad','deg'),convang(robot.m_Solution.xState_Solution(i,robot.Q2R),'rad','deg'),...
    %             convang(robot.m_Solution.xState_Solution(i,robot.Q1L),'rad','deg'),convang(robot.m_Solution.xState_Solution(i,robot.Q2L),'rad','deg'));
    %     end
end
% % end of for(.)
% if strcmp(reply,'Y')
%     fclose(coords);
% end
% % end of if(.)

% Close AVI file.
if(MAKE_FILM)
    close(mov);
end
% end of if(.)

end
% end of animate(.)
