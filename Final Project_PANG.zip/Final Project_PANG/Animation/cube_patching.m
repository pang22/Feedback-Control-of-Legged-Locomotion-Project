
function cube_patching(a,b,c,R,center)

hold on

x = [-1/2 1/2 1/2 -1/2]*a;  
y = [-1/2 -1/2 1/2 1/2]*b;   
z = [-1/2 -1/2 -1/2 -1/2]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = [-1/2 1/2 1/2 -1/2]*a; 
y = [-1/2 -1/2 1/2 1/2]*b; 
z = [1/2 1/2 1/2 1/2]*c;   
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = [1/2 1/2 1/2 1/2]*a;   
y = [-1/2 -1/2 1/2 1/2]*b; 
z = [-1/2 1/2 1/2 -1/2]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = [-1/2 -1/2 -1/2 -1/2]*a; 
y = [-1/2 -1/2 1/2 1/2]*b;   
z = [-1/2 1/2 1/2 -1/2]*c;   
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = [-1/2 -1/2 1/2 1/2]*a;   
y = [-1/2 -1/2 -1/2 -1/2]*b;
z = [-1/2 1/2 1/2 -1/2]*c;   
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = [-1/2 -1/2 1/2 1/2]*a; 
y = [1/2 1/2 1/2 1/2]*b;   
z = [-1/2 1/2 1/2 -1/2]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = 1/3*[ 1/2 1/2 1/2 1/2 1/2 1/2]*a;
y = [-1/2 -3/4 -3/4 3/4 3/4 1/2]*b;
z = [-1/2 -3/4 -1.5 -1.5 -3/4 -1/2]*c;
pos = R * [x; y; z] + [center(1)*ones(1,6); center(2)*ones(1,6); center(3)*ones(1,6)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = -1/3*[ 1/2 1/2 1/2 1/2 1/2 1/2]*a;
y = [-1/2 -3/4 -3/4 3/4 3/4 1/2]*b;
z = [-1/2 -3/4 -1.5 -1.5 -3/4 -1/2]*c;
pos = R * [x; y; z] + [center(1)*ones(1,6); center(2)*ones(1,6); center(3)*ones(1,6)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = 1/3*[1/2 1/2 -1/2 -1/2]*a;
y = [1/2 3/4 3/4 1/2]*b;
z = [-1/2 -3/4 -3/4 -1/2]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = 1/3*[1/2 1/2 -1/2 -1/2]*a;
y = [3/4 3/4 3/4 3/4]*b;
z = [-3/4 -1.5 -1.5 -3/4]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = 1/3*[1/2 1/2 -1/2 -1/2]*a;
y = -[1/2 3/4 3/4 1/2]*b;
z = [-1/2 -3/4 -3/4 -1/2]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

x = 1/3*[1/2 1/2 -1/2 -1/2]*a;
y = -[3/4 3/4 3/4 3/4]*b;
z = [-3/4 -1.5 -1.5 -3/4]*c; 
pos = R * [x; y; z] + [center(1)*ones(1,4); center(2)*ones(1,4); center(3)*ones(1,4)];
patch(pos(1,:),pos(2,:),pos(3,:),1)

%axis([-2 2 -2 2 -2 2])

end