function animate_simulink(Time,Q,Pcm,P0,P0T,PHR,P1R,P2R,P3R,P4R,PHL,P1L,P2L,P3L,P4L)

animate_robot_running(0,1,'iso',0,Time',Q',Pcm',P0',P0T',PHR',P1R',P2R',P3R',P4R',PHL',P1L',P2L',P3L',P4L')

end

