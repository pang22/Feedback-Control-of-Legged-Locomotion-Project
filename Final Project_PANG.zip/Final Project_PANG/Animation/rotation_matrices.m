function [R] = rotation_matrices(t,which_axis)

Rx = [1 0 0 ; 0 cos(t) -sin(t); 0 sin(t) cos(t)];
Ry = [cos(t) 0 sin(t); 0 1 0 ; -sin(t) 0 cos(t)];
Rz = [cos(t) -sin(t) 0; sin(t) cos(t) 0; 0 0 1];

switch which_axis
    case 1
        R = Rx;
    case 2
        R = Ry;
    case 3
        R = Rz;
end


end

