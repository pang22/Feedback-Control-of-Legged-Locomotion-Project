function plot_ellipsoid(radius,center,R,color_txt)

[x,y,z] = ellipsoid(0,0,0,radius(1),radius(2),radius(3));
[m,n]   = size(x);
xhat = R(1,1) * x + R(1,2) * y + R(1,3) * z + center(1)*ones(m,n);
yhat = R(2,1) * x + R(2,2) * y + R(2,3) * z + center(2)*ones(m,n);
zhat = R(3,1) * x + R(3,2) * y + R(3,3) * z + center(3)*ones(m,n);

surfc(xhat,yhat,zhat,'FaceColor',color_txt,'EdgeColor','none')

end



