function plot_cm(pcm,leg)


% Center of mass
w1 = linspace(0,pi/2,11);
w2 = linspace(pi/2,pi,11);
w3 = linspace(pi,3*pi/2,11);
w4 = linspace(3*pi/2,2*pi,11);
w = [w1;w2;w3;w4];
radius=.005;
xx = 18/0.5*radius*[zeros(4,1) cos(w) zeros(4,1)]+pcm(1);
yy = radius*[zeros(4,1) sin(w) zeros(4,1)]+pcm(2);

if leg==0
    pp1 = patch(xx(1,:),yy(1,:),'g');
    pp2 = patch(xx(2,:),yy(2,:),'g');
    pp3 = patch(xx(3,:),yy(3,:),'g');
    pp4 = patch(xx(4,:),yy(4,:),'g');
    
    set(pp1,'FaceColor','g');
    set(pp2,'FaceColor','g');
    set(pp3,'FaceColor','g');
    set(pp4,'FaceColor','g');
else
    pp1 = patch(xx(1,:),yy(1,:),'r');
    pp2 = patch(xx(2,:),yy(2,:),'r');
    pp3 = patch(xx(3,:),yy(3,:),'r');
    pp4 = patch(xx(4,:),yy(4,:),'r');
    
    set(pp1,'FaceColor','r');
    set(pp2,'FaceColor','r');
    set(pp3,'FaceColor','r');
    set(pp4,'FaceColor','r');
end

end