function [Seta] = IMU_symmetry_matrix
%#codegen
% This function returns the IMU symmetry matrix.
%
% Output
%
% Seta: 4x4 input symmetry matrix
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input symmetry matrix
Seta = -[0 1 0 0;
         1 0 0 0;
         0 0 0 1;
         0 0 1 0];

end




