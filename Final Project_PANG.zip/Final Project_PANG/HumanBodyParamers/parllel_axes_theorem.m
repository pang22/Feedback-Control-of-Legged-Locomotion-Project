function [I_new] = parllel_axes_theorem(I_cm,r,m)

% This function determines the inertia matrix around a new set of
% coordinates using the parallel axis theorem.

% For more details, see page 7 of the following link
% http://ocw.mit.edu/courses/aeronautics-and-astronautics/16-07-dynamics-fall-2009/lecture-notes/MIT16_07F09_Lec26.pdf

% I_cm:         Original inertia tensor around the COM
% r=(rx,ry,rz): displacement of the original (old) frame w.r.t to the new frame measured in the new frame.
% m:            mass of the object

rx = r(1);
ry = r(2);
rz = r(3);

I_new = I_cm + m * [ry^2+rz^2 -rx*ry     -rx*rz;
                    -rx*ry     rx^2+rz^2 -ry*rz;
                    -rx*rz    -ry*rz      rx^2+ry^2];
                
end

