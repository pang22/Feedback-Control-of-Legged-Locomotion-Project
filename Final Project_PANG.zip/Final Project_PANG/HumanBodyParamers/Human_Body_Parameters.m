function [L1,L2,L3,LT,W,m1,m2,m3,mT,COM1,COM2,COM3,COMT,Icm1,Icm2,Icm3,IcmT,r1,r2,r3,r4] = Human_Body_Parameters

mtot = 73;

% Modified Torso Link
% We define a modified torso link including the head, torso, upper arm,
% forearm, and head. 

% Head Link
segment_length     = 0.2033; %[m]
mbar               = 6.94/100; %
longtitudal_CM_pos = 59.76/100; %
sagittal_r         = 36.2/100;
transverse_r       = 37.6/100;
longtuidinal_r     = 31.2/100;
mH    = mbar * mtot;
LH    = segment_length;
COMHx = 0;
COMHy = 0;
COMHz = longtitudal_CM_pos * segment_length;
COMH  = [COMHx; COMHy; COMHz];
Is    = mH * (sagittal_r * segment_length)^2;
It    = mH * (transverse_r * segment_length)^2;
Il    = mH * (longtuidinal_r * segment_length)^2;
IcmH  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Torso Link
segment_length     = 0.5319; %[m]
mbar               = 43.46/100; %
longtitudal_CM_pos = 44.86/100; %
sagittal_r         = 37.2/100;
transverse_r       = 34.7/100;
longtuidinal_r     = 19.1/100;
mT    = mbar * mtot;
LT    = segment_length;
COMTx = 0;
COMTy = 0;
COMTz = longtitudal_CM_pos * segment_length;
COMT  = [COMTx; COMTy; COMTz];
Is    = mT * (sagittal_r * segment_length)^2;
It    = mT * (transverse_r * segment_length)^2;
Il    = mT * (longtuidinal_r * segment_length)^2;
IcmT  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Upper Arm
segment_length     = 0.2817; %[m]
mbar               = 2.71/100; %
longtitudal_CM_pos = 57.72/100; %
sagittal_r         = 28.5/100;
transverse_r       = 26.9/100;
longtuidinal_r     = 15.8/100;
mU    = mbar * mtot;
LU    = segment_length;
COMUx = 0;
COMUy = 0;
COMUz = longtitudal_CM_pos * segment_length;
COMU  = [COMUx; COMUy; COMUz];
Is    = mU * (sagittal_r * segment_length)^2;
It    = mU * (transverse_r * segment_length)^2;
Il    = mU * (longtuidinal_r * segment_length)^2;
IcmU  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Forearm Arm
segment_length     = 0.2689; %[m]
mbar               = 1.62/100; %
longtitudal_CM_pos = 45.74/100; %
sagittal_r         = 27.6/100;
transverse_r       = 26.5/100;
longtuidinal_r     = 12.1/100;
mF    = mbar * mtot;
LF    = segment_length;
COMFx = 0;
COMFy = 0;
COMFz = longtitudal_CM_pos * segment_length;
COMF  = [COMFx; COMFy; COMFz];
Is    = mF * (sagittal_r * segment_length)^2;
It    = mF * (transverse_r * segment_length)^2;
Il    = mF * (longtuidinal_r * segment_length)^2;
IcmF  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Hand
segment_length     = 0.0862; %[m]
mbar               = 0.61/100; %
longtitudal_CM_pos = 79.00/100; %
sagittal_r         = 62.8/100;
transverse_r       = 51.3/100;
longtuidinal_r     = 40.1/100;
mh    = mbar * mtot;
Lh    = segment_length;
COMhx = 0;
COMhy = 0;
COMhz = longtitudal_CM_pos * segment_length;
COMh  = [COMhx; COMhy; COMhz];
Is    = mh * (sagittal_r * segment_length)^2;
It    = mh * (transverse_r * segment_length)^2;
Il    = mh * (longtuidinal_r * segment_length)^2;
Icmh  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Modified Torso

% Calculate everything w.r.t the Vertex
COMHz = COMHz;
COMTz = COMTz + LH;           % w.r.t the Vertex
COMUz = COMUz + LH;           % w.r.t the Vertex
COMFz = COMFz + LU + LH;      % w.r.t the Vertex
COMhz = COMhz + LF + LU + LH; % w.r.t the Vertex

% Total mass
mtot    = mH + mT + 2*(mU+mF+mh); % total mass

% Total COM
COMtotx = 0;
COMtoty = 0; 
COMtotz = (mH*COMHz + mT*COMTz + 2*(mU*COMUz + mF*COMFz + mh*COMhz))/mtot; % w.r.t the Vertex
COMtotz_wrt_hip = LH + LT - COMtotz;
COMtot  = [COMtotx; COMtoty; COMtotz_wrt_hip];

% Some Kinematic Parameters
W = 0.15; % Hip Length I guess
COMhx_wrt_middleaxis = W + 0.02; % I guess (horizonal distance between the hand, upper arm and forarem COM w.r.t. the central line passing through the torso COM).
COMUx_wrt_middleaxis = COMhx_wrt_middleaxis;
COMFx_wrt_middleaxis = COMhx_wrt_middleaxis;

% Modify Inertia Tensors
IH  = parllel_axes_theorem(IcmH,[0; 0; -COMtotz+COMHz],mH);
IT  = parllel_axes_theorem(IcmT,[0; 0; -COMtotz+COMTz],mT);
IhR = parllel_axes_theorem(Icmh,[COMhx_wrt_middleaxis;  0; -COMtotz+COMhz],mh); % right hand
IUR = parllel_axes_theorem(IcmU,[COMUx_wrt_middleaxis;  0; -COMtotz+COMUz],mU); % right upper arm
IFR = parllel_axes_theorem(IcmF,[COMFx_wrt_middleaxis;  0; -COMtotz+COMFz],mF); % right upper arm
IhL = parllel_axes_theorem(Icmh,[-COMhx_wrt_middleaxis; 0; -COMtotz+COMhz],mh); % left hand
IUL = parllel_axes_theorem(IcmU,[-COMUx_wrt_middleaxis; 0; -COMtotz+COMUz],mU); % left upper arm
IFL = parllel_axes_theorem(IcmF,[-COMFx_wrt_middleaxis; 0; -COMtotz+COMFz],mF); % left upper arm

% Equivalent Torso
mT   = mtot;
IcmT = IH + IT + IhR + IhL + IUR + IUL + IFR + IFL;
COMT = COMtot;

%--------------------------------------------------------------------------

% Thigh Link
segment_length     = 0.4222; %[m]
mbar               = 14.16/100; %
longtitudal_CM_pos = 40.95/100; %
sagittal_r         = 32.9/100;
transverse_r       = 32.9/100;
longtuidinal_r     = 14.9/100;
m3    = mbar * mtot;
L3    = segment_length;
COM3x = 0;
COM3y = 0;
COM3z = longtitudal_CM_pos * segment_length;
COM3  = [COM3x; COM3y; COM3z];
Is    = m3 * (sagittal_r * segment_length)^2;
It    = m3 * (transverse_r * segment_length)^2;
Il    = m3 * (longtuidinal_r * segment_length)^2;
Icm3  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Shin Link (From Knee to Ankle)
segment_length     = 0.4403; %[m]
mbar               = 4.33/100; %
longtitudal_CM_pos = 43.95/100; %
sagittal_r         = 25.1/100;
transverse_r       = 24.6/100;
longtuidinal_r     = 10.2/100;
m2    = mbar * mtot;
L2    = segment_length;
COM2x = 0;
COM2y = 0;
COM2z = longtitudal_CM_pos * segment_length;
COM2  = [COM2x; COM2y; COM2z];
Is    = m2 * (sagittal_r * segment_length)^2;
It    = m2 * (transverse_r * segment_length)^2;
Il    = m2 * (longtuidinal_r * segment_length)^2;
Icm2  = diag([It Is Il]);

%--------------------------------------------------------------------------

% Foot (From Bobby's paper)
% I assume a cylinder for the foot link with the radius R1 and length L1
% see: http://hyperphysics.phy-astr.gsu.edu/hbase/icyl.html
m1 = 1;
L1 = 0.0;
R1 = 0.7*L1;
COM1x = 0;
COM1y = 0;
COM1z = 1/2*L1; % COM at the middle
COM1  = [COM1x; COM1y; COM1z];
Izz  = 1/2*m1*R1^2;
Ixx  = 1/4*m1*R1^2+1/12*m1*L1^2;
Iyy  = Ixx;
Icm1 = diag([Ixx Iyy Izz]);

%--------------------------------------------------------------------------

% Gear ratios
r1 = 1;
r2 = 1;
r3 = 1;
r4 = 1;

end

