function b = binom(n)
%#codegen
    % BINOM compute a vector of binomial coefficients
    b = 1;
    for k=1:n
        b = [0 b]+[b 0];
    end
end
