/*
 * bezierd.c
 *
 * Code generation for function 'bezierd'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "bezierd.h"
#include "bezierd_data.h"

/* Function Definitions */
void bezierd(const emlrtStack *sp, const real_T afra[84], real_T s, real_T
             value[4])
{
  int32_T i;
  real_T x[20];
  real_T y[20];
  int32_T j;
  static const int32_T iv0[20] = { 20, 380, 3420, 19380, 77520, 232560, 542640,
    1007760, 1511640, 1847560, 1847560, 1511640, 1007760, 542640, 232560, 77520,
    19380, 3420, 380, 20 };

  for (i = 0; i < 4; i++) {
    value[i] = 0.0;
  }

  /* % */
  for (i = 0; i < 20; i++) {
    x[i] = 1.0;
    y[i] = 1.0;
  }

  for (i = 0; i < 19; i++) {
    x[1 + i] = s * x[i];
    y[1 + i] = (1.0 - s) * y[i];
    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }

  for (i = 0; i < 4; i++) {
    value[i] = 0.0;
    for (j = 0; j < 20; j++) {
      emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
      value[i] += (afra[i + ((1 + j) << 2)] - afra[i + (j << 2)]) * (real_T)
        iv0[j] * x[j] * y[19 - j];
    }

    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }
}

/* End of code generation (bezierd.c) */
