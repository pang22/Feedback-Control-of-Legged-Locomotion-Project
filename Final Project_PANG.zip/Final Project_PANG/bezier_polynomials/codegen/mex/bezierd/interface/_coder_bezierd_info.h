/*
 * _coder_bezierd_info.h
 *
 * Code generation for function 'bezierd'
 *
 */

#ifndef ___CODER_BEZIERD_INFO_H__
#define ___CODER_BEZIERD_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_bezierd_info.h) */
