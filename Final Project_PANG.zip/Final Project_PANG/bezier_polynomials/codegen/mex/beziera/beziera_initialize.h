/*
 * beziera_initialize.h
 *
 * Code generation for function 'beziera_initialize'
 *
 */

#ifndef __BEZIERA_INITIALIZE_H__
#define __BEZIERA_INITIALIZE_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "beziera_types.h"

/* Function Declarations */
extern void beziera_initialize(emlrtContext *aContext);

#endif

/* End of code generation (beziera_initialize.h) */
