/*
 * beziera.h
 *
 * Code generation for function 'beziera'
 *
 */

#ifndef __BEZIERA_H__
#define __BEZIERA_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "beziera_types.h"

/* Function Declarations */
extern void beziera(const emlrtStack *sp, const real_T afra[84], real_T s,
                    real_T value[4]);

#endif

/* End of code generation (beziera.h) */
