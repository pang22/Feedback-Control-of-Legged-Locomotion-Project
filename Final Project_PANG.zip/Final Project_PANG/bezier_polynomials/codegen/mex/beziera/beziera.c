/*
 * beziera.c
 *
 * Code generation for function 'beziera'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "beziera.h"
#include "beziera_data.h"

/* Function Definitions */
void beziera(const emlrtStack *sp, const real_T afra[84], real_T s, real_T
             value[4])
{
  int32_T i;
  real_T x[19];
  real_T y[19];
  int32_T j;
  static const int32_T iv0[19] = { 380, 6840, 58140, 310080, 1162800, 3255840,
    7054320, 12093120, 16628040, 18475600, 16628040, 12093120, 7054320, 3255840,
    1162800, 310080, 58140, 6840, 380 };

  for (i = 0; i < 4; i++) {
    value[i] = 0.0;
  }

  /* % */
  for (i = 0; i < 19; i++) {
    x[i] = 1.0;
    y[i] = 1.0;
  }

  for (i = 0; i < 18; i++) {
    x[1 + i] = s * x[i];
    y[1 + i] = (1.0 - s) * y[i];
    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }

  for (i = 0; i < 4; i++) {
    value[i] = 0.0;
    for (j = 0; j < 19; j++) {
      emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
      value[i] += ((afra[i + ((2 + j) << 2)] - 2.0 * afra[i + ((1 + j) << 2)]) +
                   afra[i + (j << 2)]) * (real_T)iv0[j] * x[j] * y[18 - j];
    }

    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }
}

/* End of code generation (beziera.c) */
