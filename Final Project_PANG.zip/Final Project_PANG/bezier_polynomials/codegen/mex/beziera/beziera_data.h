/*
 * beziera_data.h
 *
 * Code generation for function 'beziera_data'
 *
 */

#ifndef __BEZIERA_DATA_H__
#define __BEZIERA_DATA_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "beziera_types.h"

/* Variable Declarations */
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;

#endif

/* End of code generation (beziera_data.h) */
