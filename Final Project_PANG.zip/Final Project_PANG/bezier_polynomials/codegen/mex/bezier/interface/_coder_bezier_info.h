/*
 * _coder_bezier_info.h
 *
 * Code generation for function 'bezier'
 *
 */

#ifndef ___CODER_BEZIER_INFO_H__
#define ___CODER_BEZIER_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_bezier_info.h) */
