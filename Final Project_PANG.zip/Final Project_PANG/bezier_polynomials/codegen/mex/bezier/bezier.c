/*
 * bezier.c
 *
 * Code generation for function 'bezier'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "bezier.h"
#include "bezier_data.h"

/* Function Definitions */
void bezier(const emlrtStack *sp, const real_T afra[84], real_T s, real_T value
            [4])
{
  int32_T i;
  real_T x[21];
  real_T y[21];
  int32_T j;
  static const int32_T iv0[21] = { 1, 20, 190, 1140, 4845, 15504, 38760, 77520,
    125970, 167960, 184756, 167960, 125970, 77520, 38760, 15504, 4845, 1140, 190,
    20, 1 };

  for (i = 0; i < 4; i++) {
    value[i] = 0.0;
  }

  /* %     */
  for (i = 0; i < 21; i++) {
    x[i] = 1.0;
    y[i] = 1.0;
  }

  for (i = 0; i < 20; i++) {
    x[1 + i] = s * x[i];
    y[1 + i] = (1.0 - s) * y[i];
    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }

  for (i = 0; i < 4; i++) {
    value[i] = 0.0;
    for (j = 0; j < 21; j++) {
      emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
      value[i] += afra[i + (j << 2)] * (real_T)iv0[j] * x[j] * y[20 - j];
    }

    emlrtBreakCheckFastR2012b(emlrtBreakCheckR2012bFlagVar, sp);
  }
}

/* End of code generation (bezier.c) */
