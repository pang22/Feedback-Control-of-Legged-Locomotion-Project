function [Cineq,Ceq] = Nonlinear_Constraints_MotionPlanning(p,optim_option)

% This function returns the inequality and equality constraints for the
% motion planning algorithm.

% Inputs:
%
% p: decision variables of dimension 8*M-2, where M is the degree of the Bezier polynomial
% optim_option: options for the motion planning algorithm
%
% Outputs:
%
% Cineq: inequality constraints
% Ceq:   equality constraints
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------

% Extract optimization parameters
M                 = optim_option.M;
AT                = optim_option.AT;
RT                = optim_option.RT;
RF                = optim_option.RF;
ds_min            = optim_option.ds_min;
q_min_stance      = optim_option.q_min_stance;
q_max_stance      = optim_option.q_max_stance;
dq_min_stance     = optim_option.dq_min_stance;
dq_max_stance     = optim_option.dq_max_stance;
u_max             = optim_option.u_max;
F_min_v           = optim_option.F_min_v;
F_min_v_impuslive = optim_option.F_min_v_impuslive;
mu_s              = optim_option.mu_s;
step_length_min   = optim_option.step_length_min;
ave_velocity_min  = optim_option.ave_velocity_min;
p_swing_h_min     = optim_option.p_swing_h_min;
t_s_min           = optim_option.t_s_min;
vcm_min           = optim_option.vcm_min;

%--------------------------------------------------------------------------

% Extract decision variables
[Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(p,M);

% Solve the stance ODE
[t_stance,q_stance,dq_stance,ddq_stance,u_stance,y_stance,dy_stance,F_stance,s_stance,ds_stance,p_swing,dp_swing] = solve_stance_ODE(Xs_plus,a_matrix,theta_plus,theta_minus,AT,RT,RF);

%--------------------------------------------------------------------------

% Inequality constraints
Cineq = [];

% Feasibility of theta limits
Cineq = [Cineq; theta_plus - theta_minus];


% Feasibility of impcat force (friction cone conditions)
F_impulsive_v = F_imp(3);
F_impulsive_h = sqrt(F_imp(1)^2+F_imp(2)^2);
%--------------------------------------------------------------------------
% Modified code
% F_impulsive_v = F_imp(2);
% F_impulsive_h = F_imp(1);
%--------------------------------------------------------------------------
Cineq = [Cineq;  F_min_v_impuslive - F_impulsive_v];
Cineq = [Cineq;  abs(F_impulsive_h) - mu_s * F_impulsive_v];
% Cineq = [Cineq; -F_impulsive_h - mu_s * F_impulsive_v]; %Do i need this?

%--------------------------------------------------------------------------
% Cineq = [Cineq; -dp_swing(2,1)];%Positive vertical v at the beginning of the step
Cineq = [Cineq; -dp_swing(3,1)];%Positive vertical v at the beginning of the step
% --------------------------------------------------------------------------

% Feasibility of Bezier matrix
% Cineq = [Cineq; max(a_matrix')'     - q_max_stance(4:end)];
% Cineq = [Cineq; q_min_stance(4:end) - min(a_matrix')'];
%--------------------------------------------------------------------------
% Modified code
% Cineq = [Cineq; max(a_matrix')'     - q_max_stance(2:end)];
% Cineq = [Cineq; q_min_stance(2:end) - min(a_matrix')'];
Cineq = [Cineq; max(a_matrix')'     - q_max_stance(3:end)];
Cineq = [Cineq; q_min_stance(3:end) - min(a_matrix')'];
%--------------------------------------------------------------------------

% % Strictly increasing phasing variable
Cineq = [Cineq; ds_min - min(ds_stance)];


% Feasibilty of positions
Cineq = [Cineq; q_min_stance - min(q_stance')'];
Cineq = [Cineq; max(q_stance')' - q_max_stance];


% % Feasibilty of velocity
Cineq = [Cineq; dq_min_stance - min(dq_stance')'];
Cineq = [Cineq; max(dq_stance')' - dq_max_stance];

% Feasibilty of torque
% Cineq = [Cineq; -u_max*ones(6,1) - min(u_stance')'];
% Cineq = [Cineq;  max(u_stance')' - u_max*ones(6,1)];
%--------------------------------------------------------------------------
%(CAUSING ISSUE!!!)
% Modified code 
Cineq = [Cineq; -u_max*ones(4,1) - min(u_stance')'];
Cineq = [Cineq;  max(u_stance')' - u_max*ones(4,1)];
%--------------------------------------------------------------------------

% Feasibilty of GRF (friction cone conditions)
Cineq = [Cineq; F_min_v + max(-F_stance(3,:))];
Cineq = [Cineq; max( sqrt(F_stance(1,:).^2+F_stance(2,:).^2) - mu_s * F_stance(3,:))];
Cineq = [Cineq; max(-sqrt(F_stance(1,:).^2+F_stance(2,:).^2) - mu_s * F_stance(3,:))];
%--------------------------------------------------------------------------
% Modified code %(CAUSING ISSUE!!!)
% Cineq = [Cineq; F_min_v + max(-F_stance(2,:))]; %Is this right?
% 
% Cineq = [Cineq; max( abs(F_stance(1,:)) - mu_s * F_stance(2,:))]; %from L4
% %--------------------------------------------------------------------------
% Cineq = [Cineq; max(-abs(F_stance(1,:)) - mu_s * F_stance(2,:))];


%--------------------------------------------------------------------------
% Added code (Causing less problem)
% Step length and velocity requiremnets
step_length   = p_swing(2,end);
Cineq = [Cineq; step_length_min - step_length];
 
ave_velocity  = step_length/t_stance(end);
Cineq = [Cineq; ave_velocity_min - ave_velocity];
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------% TEST COMMENTED OUT
% % Foot clearance

% fk_output = joint_position(Xs_plus(1:5),robot_params);
% p_swing_initial = fk_output(:,6);
% 
% fk_output = joint_position(Xs_minus(1:5),robot_params);
% p_swing_final = fk_output(:,6);

fk_output = FK_hw31(Xs_plus(1:6));
p_swing_initial = fk_output(:,8);

fk_output = FK_hw31(Xs_minus(1:6));
p_swing_final = fk_output(:,8);
% 
% Foot clearance 
% p_swing_final   = p1L;
Cineq = [Cineq; p_swing_initial(2) + p_swing_h_min]; %distance between 2 foot at the beginning position is bigger than 0.1
Cineq = [Cineq; p_swing_h_min      - p_swing_final(2)];
% Cineq = [Cineq; max(-p_swing(2,:))]; %Don't step below ground
% Cineq = [Cineq; max(-p_swing(2,:))]; %Don't step below ground
% Cineq = [Cineq; dp_swing(2,end)]; %end velocity is pointing down
% Cineq = [Cineq; 0.02-max(p_swing(2,:))]; %The step height is at least 0.02m

Cineq = [Cineq; max(-p_swing(3,:))]; %Don't step below ground
Cineq = [Cineq; dp_swing(3,end)]; %end velocity is pointing down
Cineq = [Cineq; 0.02-max(p_swing(3,:))]; %The step height is at least 0.02m

% Cineq = [Cineq; 0.1-min(abs(p_swing(1,:)))];
% 
% %--------------------------------------------------------------------------
% % Delete for now
% % CoM velocity at the beginning
% % [vcm J_cm dJ_cm v0 J0 dJ0 v0T vHL vHR] =  Robot_VelAccel_Right(Xs_plus(1:9),Xs_plus(10:18));
% % Cineq = [Cineq; vcm_min-vcm(2)];
% vcm = robot_velocity(Xs_plus(1:5),Xs_plus(6:10),robot_params); 
% Cineq = [Cineq; vcm_min-vcm(1)];
% %--------------------------------------------------------------------------
% 
% % Time constraint
Cineq = [Cineq; t_s_min - t_stance(end)]; %The step length is not too short
% 
% % END OF COMMENTED OUT LINE
% %--------------------------------------------------------------------------% END OF COMMENTED OUT LINE

%Remove all inequality constraints
Cineq = [];
Cineq = [Cineq; max(-p_swing(3,:))]; %Don't step below ground
Cineq = [Cineq; ds_min - min(ds_stance)]; % strictly increasing phasing variable
Cineq = [Cineq; p_swing_h_min      - p_swing_final(2)]; % step length must be greater than the limit

% Cineq = [Cineq;  F_min_v_impuslive - F_impulsive_v];
% Cineq = [Cineq; F_min_v + max(-F_stance(3,:))];
Cineq = [Cineq; dp_swing(3,end)]; %end velocity is pointing down
Cineq = [Cineq; 0.02-max(p_swing(3,:))]; %The step height is at least 0.02m

Cineq = [Cineq; p_swing_initial(2) + p_swing_h_min]; %distance between 2 foot at the beginning position is bigger than 0.1
Cineq = [Cineq; p_swing_h_min      - p_swing_final(2)];

Cineq = [Cineq; -u_max*ones(4,1) - min(u_stance')'];
Cineq = [Cineq;  max(u_stance')' - u_max*ones(4,1)];

step_length   = p_swing(2,end);
Cineq = [Cineq; step_length_min - step_length];
 
ave_velocity  = step_length/t_stance(end);
Cineq = [Cineq; ave_velocity_min - ave_velocity];
%--------------------------------------------------------------------------

% Equality constarints
Ceq = [];

% Periodicity condition
EQ_Periodicity = [q_stance(:,end); dq_stance(:,end)] - Xs_minus;


% Ceq = [Ceq; EQ_Periodicity(1:5)];
% Ceq = [Ceq; EQ_Periodicity(6:10)];
Ceq = [Ceq; EQ_Periodicity(1:6)];
Ceq = [Ceq; EQ_Periodicity(7:12)];

%--------------------------------------------------------------------------
%delete for now
% Impact condition
%  Ceq = [Ceq; p_swing_final(2)];
  Ceq = [Ceq; p_swing_final(3)];
%--------------------------------------------------------------------------

% save('tempX.mat','p');
end


