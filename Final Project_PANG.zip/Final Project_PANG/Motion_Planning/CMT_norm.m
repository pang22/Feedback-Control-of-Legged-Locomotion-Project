function [U_plus] = CMT_norm(U)

sum = 0;
n   = length(U);
for k=1:n
    if U(k)>0
        sum = sum + U(k);
    end
end 
U_plus = sum;

end

