function [value,isterminal,direction] = stance_phase_events(t,x,leg,theta_plus,theta_minus,alpha)

% This function calculates the evnt function for the stance phase
%
% Inputs:
% t: time
% x: 18-dim state variable during the stance phase
% leg: 0 for the right stance and 1 for the left stance
% theta_plus:  initial value of theta on the orbit
% theta_minus: final value of theta on the orbit
% alpha: coefficient matrix for the bezier polynomial
%
% Outputs:
% value: the event-function
% isterminal: stop condition
% direction: the time derivative sign
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------------------------------------------------------
% Position and velocity
% Modified code
% q  = x(1:5);
% dq = x(6:10);
%--------------------------------------------------------------------------
q  = x(1:6);
dq = x(7:12);

% Swing leg end
% Modified code
% fk_output = joint_position(q,robot_params);
% value = fk_output(2,6); %swing leg end position
%--------------------------------------------------------------------------
fk_output = FK_hw31(q);
value = fk_output(3,8); %swing leg end z position

[s,ds,ds_dq] = scaled_phasing_variable(x,leg,theta_plus,theta_minus);
if s>0.9
    % nothing
else
    value = 1;
end

% Stop conditions
isterminal(1) = 1;
direction(1)  = -1; % It is decreasing

end
