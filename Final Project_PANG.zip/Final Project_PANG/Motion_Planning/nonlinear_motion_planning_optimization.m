%%
clc
clear all
% addpath('C:\Users\Zhoubao Pang\OneDrive\Classes\Spring 2019\Legged Locomotion\Final Project\symbolic calculation')
% Optimization parameters
optim_option = [];

% Specify Bezier polynmoial order
M = 5;
optim_option.M = M;

% Specify minimum and maximum of joint angles in (deg)

%--------------------------------------------------------------------------
qy_min = -30; % torso row angle
qy_max =  30;
qx_min = -30; % torso pitch angle
qx_max =  0; 
qSTH_R_min = -5; % stance hip roll angle
qSTH_R_max = 20; 
qSTH_P_min = 180-45; %stance hip pitch angle
qSTH_P_max = 180+45;
qSWH_R_min = -5; % swing hip roll angle
qSWH_R_max = 20; 
qSWH_P_min = 180-45; % swing hip pitch angle
qSWH_P_max = 180+45;
%--------------------------------------------------------------------------

q_min_stance = pi/180 * [qy_min; qx_min; qSTH_R_min; qSTH_P_min; qSWH_R_min; qSWH_P_min];
q_max_stance = pi/180 * [qy_max; qx_max; qSTH_R_max; qSTH_P_max; qSWH_R_max; qSWH_P_max];

optim_option.q_min_stance = q_min_stance;
optim_option.q_max_stance = q_max_stance;

% Specify maximum angular velocity in (rad/s)
dq_max = 3*pi;

% Calculate the velocity bounds
%--------------------------------------------------------------------------
% Modified code
dq_min_stance = -dq_max * ones(6,1);
dq_max_stance =  dq_max * ones(6,1);
%--------------------------------------------------------------------------
optim_option.dq_min_stance = dq_min_stance;
optim_option.dq_max_stance = dq_max_stance;

% Specify other parameters
ds_min            = 0.1;  % The minimum value for the time deriavtive of the sacled phasing varibale
u_max             = 2000;  % maximum torque values for DC motors in (Nm)
F_min_v           = 10;   % mimunum value for the vertical component of the GRF during stance phase in (N)
F_min_v_impulsive = 0.1;  % minumum value for the vertical component of the impulsive GRF during flight to stance impact in (N)
mu_s              = 0.9;  % friction coefficient between the leg end and ground

step_length_min   = 0.1;  % minimum step length in (m)
%--------------------------------------------------------------------------


ave_velocity_min  = 0.4;  % minimum average velocity of the robot in (m/s)
AT                = 1e-6; % Absolute tolerance for ODE solver
RT                = 1e-3; % Relative tolerance for ODE solver
RF                = 1;    % Refine factor for ODE solver
p_swing_h_min     = 0.1;
t_s_min           = 0.2;
vcm_min           = 0.8;

% Calculate other parameters
optim_option.ds_min            = ds_min;
optim_option.u_max             = u_max;
optim_option.F_min_v           = F_min_v;
optim_option.F_min_v_impuslive = F_min_v_impulsive;
optim_option.mu_s              = mu_s;
optim_option.AT                = AT;
optim_option.RT                = RT;
optim_option.RF                = RF;
optim_option.step_length_min   = step_length_min;
optim_option.ave_velocity_min  = ave_velocity_min;
optim_option.p_swing_h_min     = p_swing_h_min;
optim_option.t_s_min           = t_s_min;
optim_option.vcm_min           = vcm_min;

% Parallel computation enabled
%matlabpool(24);

%--------------------------------------------------------------------------
%%
% Optimization

SW = warning('off', 'MATLAB:ode45:IntegrationTolNotMet');

global history

history.x    = [];
history.fval = [];

% fmincon options
MinimizatinOptions = optimset('OutputFcn',[],...
    'MaxFunEvals',1e6,...
    'TolCon',1e-3,...
    'TolFun',1e-4,...
    'TolX',1e-15,...
    'Algorithm','active-set',...
    'AlwaysHonorConstraints','bounds',...
    'Display','iter-detailed',...
    'FunValCheck','on',...
    'DiffMaxChange', 0.01,...
    'DiffMinChange', 1e-4,...
    'MaxIter', 1000,...
    'UseParallel','always');

% Initial condition for the optimizer
which_initial_condition = 'random';
EXITFLAG = -2;


a_min  = pi/180 * [qSTH_R_min; qSTH_P_min; qSWH_R_min; qSWH_P_min];
a_max  = pi/180 * [qSTH_R_max; qSTH_P_max; qSWH_R_max; qSWH_P_max];

a_lb   = repeat_vector(a_min,M-3);
a_ub   = repeat_vector(a_max,M-3);
lb     = [q_min_stance; dq_min_stance; a_lb];
ub     = [q_max_stance; dq_max_stance; a_ub];


%%
while EXITFLAG==-2
    
    switch which_initial_condition
        case 'random'
            %--------------------------------------------------------------------------
            nX = 20; %Num of variables to optimize

            %% my IC
            load('myIC')
            X0 = X + 0.01*randn(20,1);
            %--------------------------------------------------------------------------
            
    end % end of witch
    
    % fmincon
    [X,FVAL,EXITFLAG,OUTPUT,LAMBDA,GRAD,HESSIAN] = fmincon(@Nonlinear_Cost_MotionPlanning,X0,[],[],[],[],lb,ub,@Nonlinear_Constraints_MotionPlanning,MinimizatinOptions,optim_option);
%     X = ga(@Nonlinear_Cost_MotionPlanning,20,[],[],[],[],lb,ub,@Nonlinear_Constraints_MotionPlanning,optim_option);

    [Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(X,M);
    
    %EXITFLAG=0;
    
end % end of while

% Close matlabpool
%matlabpool close

%% end of code %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
