function [dx] = stance_closed_loop_dynamics(t,x,leg,theta_plus,theta_minus,alpha)

% This function calculates the derivative of the state vector for the stance phase.

% Modified code
% q  = x(1:5);
% dq = x(6:10);
%--------------------------------------------------------------------------
q  = x(1:6);
dq = x(7:12);
%--------------------------------------------------------------------------
% Modified code
% Dynamic terms
[D,H,B,Cdq,G] = stance_phase_dynamic_terms(q,dq,leg);
%--------------------------------------------------------------------------

% Controller
[u,h,dh] = normal_controller(x,leg,theta_plus,theta_minus,alpha);

%--------------------------------------------------------------------------
% Modified code
% From L4
% dx = [dq; -inv(D)*(Cdq+G)] + [zeros(5,1);inv(D)*B*u];
dx = [dq; -inv(D)*(Cdq+G)] + [zeros(6,1);inv(D)*B*u];
%--------------------------------------------------------------------------
end

