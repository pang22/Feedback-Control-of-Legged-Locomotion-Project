function [Time,Leg,Q,dQ,ddQ,U,Y,dY,F,S,dS,IMU_S,IMU_dS,YAW_T,ROLL_T,PITCH_T,dYAW_T,dROLL_T,dPITCH_T,YAW_HR,ROLL_HR,PITCH_HR,dYAW_HR,dROLL_HR,dPITCH_HR,YAW_HL,ROLL_HL,PITCH_HL,dYAW_HL,dROLL_HL,dPITCH_HL,IMU_theta_plus,IMU_theta_minus,Pcm,P0,P0T,PHR,P1R,P2R,P3R,PHL,P1L,P2L,P3L] = simulate_optim_sol(X,optim_option,N_steps,animate)

% This function simulates the optimal solution of the motion planning
% algorithm.

%--------------------------------------------------------------------------

% Extract optimization parameters
M                 = optim_option.M;
AT                = optim_option.AT;
RT                = optim_option.RT;
RF                = optim_option.RF;
ds_min            = optim_option.ds_min;
q_min_stance      = optim_option.q_min_stance;
q_max_stance      = optim_option.q_max_stance;
dq_min_stance     = optim_option.dq_min_stance;
dq_max_stance     = optim_option.dq_max_stance;
u_max             = optim_option.u_max;
F_min_v           = optim_option.F_min_v;
F_min_v_impuslive = optim_option.F_min_v_impuslive;
mu_s              = optim_option.mu_s;
step_length_min   = optim_option.step_length_min;
ave_velocity_min  = optim_option.ave_velocity_min;
p_swing_h_min     = optim_option.p_swing_h_min;
t_s_min           = optim_option.t_s_min;

%--------------------------------------------------------------------------

% Extract optimal solution

[Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(X,M);
[IMU_theta_plus,~,~]  = IMU_phasing_variable(Xs_plus,0);
[IMU_theta_minus,~,~] = IMU_phasing_variable(Xs_minus,0);

%--------------------------------------------------------------------------

% Loop
gait_number = 1;
leg         = 0; % initiate with the riht stance
t_initial   = 0; % initial time
T           = 2; % maximum stance time
p_support   = [0; 0; 0];

% Save data
Time = [];
Leg  = [];
Q    = [];
dQ   = [];
ddQ  = [];
U    = [];
Y    = [];
dY   = [];
F    = [];
S    = [];
dS   = [];
IMU_S  = [];
IMU_dS = [];
YAW_T     = [];
ROLL_T    = [];
PITCH_T   = [];
dYAW_T    = [];
dROLL_T   = [];
dPITCH_T  = [];
YAW_HR    = [];
ROLL_HR   = [];
PITCH_HR  = [];
dYAW_HR   = [];
dROLL_HR  = [];
dPITCH_HR = [];
YAW_HL    = [];
ROLL_HL   = [];
PITCH_HL  = [];
dYAW_HL   = [];
dROLL_HL  = [];
dPITCH_HL = [];
Pcm  = [];
P0   = [];
P0T  = [];
PHR  = [];
P1R  = [];
P2R  = [];
P3R  = [];
PHL  = [];
P1L  = [];
P2L  = [];
P3L  = [];
while gait_number <= N_steps
    %--------------------------------------------------------------------------
    
    % SOlve ODE
    t_span  = [t_initial t_initial+T];
    x0      = Xs_plus;
    options = odeset('AbsTol',AT,'RelTol',RT,'Refine',RF,'MaxStep',0.01,'events',@stance_phase_events);
    t       = [];
    x       = [];
    tic;
    [t,x]   = ode113(@stance_closed_loop_dynamics,t_span,x0,options,leg,theta_plus,theta_minus,a_matrix);
    toc;
    x_temp  = x;
    x       = x_temp';
    q       = x(1:9,:);  % Position
    dq      = x(10:18,:); % Velocity
    
    % Calculate u, y, dy, ddq, GRF, s, ds and p_swing
    [~,n]    = size(q);
    Leg      = [Leg leg*ones(1,n)];
    Time     = [Time t'];
    Q        = [Q q];
    dQ       = [dQ dq];
    for k=1:n
        [u_temp,y_temp,dy_temp] = normal_controller(x(:,k),leg,theta_plus,theta_minus,a_matrix);
        U   = [U u_temp];
        Y   = [Y y_temp];
        dY  = [dY dy_temp];
        [ddq_temp,F_temp] = stance_phase_dynamics(q(:,k),dq(:,k),u_temp,leg);
        ddQ = [ddQ ddq_temp];
        F   = [F F_temp];
        [s_temp,ds_temp,~] = scaled_phasing_variable(x(:,k),leg,theta_plus,theta_minus);
        S   = [S s_temp];
        dS  = [dS ds_temp];
        [s_temp,ds_temp,~] = IMU_scaled_phasing_variable(x(:,k),leg,IMU_theta_plus,IMU_theta_minus);
        IMU_S   = [IMU_S s_temp];
        IMU_dS  = [IMU_dS ds_temp];
        [R_T_IMU R_RH_IMU R_LH_IMU dR_T_IMU dR_RH_IMU dR_LH_IMU] = Cfcn_IMU_Rotation_Matrices(q(:,k),dq(:,k));
        [yaw_T,roll_T,pitch_T,dyaw_T,droll_T,dpitch_T]       = IMU_ZYX(R_T_IMU,dR_T_IMU);
        [yaw_HR,roll_HR,pitch_HR,dyaw_HR,droll_HR,dpitch_HR] = IMU_ZYX(R_RH_IMU,dR_RH_IMU);
        [yaw_HL,roll_HL,pitch_HL,dyaw_HL,droll_HL,dpitch_HL] = IMU_ZYX(R_LH_IMU,dR_LH_IMU);
        YAW_T     = [YAW_T     yaw_T];
        ROLL_T    = [ROLL_T    roll_T];
        PITCH_T   = [PITCH_T   pitch_T];
        dYAW_T    = [dYAW_T    dyaw_T];
        dROLL_T   = [dROLL_T   droll_T];
        dPITCH_T  = [dPITCH_T  dpitch_T];
        YAW_HR    = [YAW_HR    yaw_HR];
        ROLL_HR   = [ROLL_HR   roll_HR];
        PITCH_HR  = [PITCH_HR  pitch_HR];
        dYAW_HR   = [dYAW_HR   dyaw_HR];
        dROLL_HR  = [dROLL_HR  droll_HR];
        dPITCH_HR = [dPITCH_HR dpitch_HR];
        YAW_HL    = [YAW_HL    yaw_HL];
        ROLL_HL   = [ROLL_HL   roll_HL];
        PITCH_HL  = [PITCH_HL  pitch_HL];
        dYAW_HL   = [dYAW_HL   dyaw_HL];
        dROLL_HL  = [dROLL_HL  droll_HL];
        dPITCH_HL = [dPITCH_HL dpitch_HL];
        if leg==0 % right stance
            [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Right(q(:,k));
            [v1R v1L J1R J1L dJ1R dJ1L] = Cfcn_Robot_VelAccel_LegEnds_Right(q(:,k),dq(:,k));
        else % left stance
            [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Left(q(:,k));
            [v1R v1L J1R J1L dJ1R dJ1L] = Cfcn_Robot_VelAccel_LegEnds_Left(q(:,k),dq(:,k));
        end % end of if
        Pcm = [Pcm pcm+p_support];
        P0  = [P0 p0+p_support];
        P0T = [P0T p0T+p_support];
        PHR = [PHR pHR+p_support];
        P1R = [P1R p1R+p_support];
        P2R = [P2R p2R+p_support];
        P3R = [P3R p3R+p_support];
        PHL = [PHL pHL+p_support];
        P1L = [P1L p1L+p_support];
        P2L = [P2L p2L+p_support];
        P3L = [P3L p3L+p_support];
    end % end of loop
    
    % Impact
    qs_minus  = q(:,end);
    dqs_minus = dq(:,end);
    [qs_plus,dqs_plus,F_imp,dz_plus] = impact_map(qs_minus,dqs_minus,leg);
    Xs_plus = [qs_plus; dqs_plus];
    
    % Next step
    if leg==0
        p_swing = P1L(:,end);
    else
        p_swing = P1R(:,end);
    end
    p_support   = p_swing;
    gait_number = gait_number + 1;
    leg         = mod(leg+1,2);
    t_initial   = Time(end);
    
end % end while

% Animate?
if animate == 1
    avifile_name = 'Optim_Gait_Speedp6_Periodp5_CMTp07_front';
    MAKE_FILM   = 0;
    shadowing   = 1;
    robot_view  = 'side';
    slow_motion = 0;
    animate_robot_walking_ver2(avifile_name,MAKE_FILM,shadowing,robot_view,slow_motion,Time,Q,Pcm,P0,P0T,PHR,P1R,P2R,P3R,PHL,P1L,P2L,P3L)
end

end

