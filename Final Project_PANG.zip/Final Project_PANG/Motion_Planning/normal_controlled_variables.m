function [h0,dh0,dh0_dq] = normal_controlled_variables(x,leg)

% This function calculates the controlled variable.
%
% Inputs:
% x:   18-dim state variable during the stance phase
% leg: 0 for the right stance and 1 for the left stance
%
% Outputs:
% h0:     6-dim controlled variables
% dh0:    6-dim time derivative of controlled varaibles
% dh0_dq: 6x9 Jacobian matrix
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Position and velocity
% q  = x(1:9);
% dq = x(10:18);
%--------------------------------------------------------------------------
% Modified code
% q  = x(1:5);
% dq = x(6:10);
%--------------------------------------------------------------------------
q  = x(1:6);
dq = x(7:12);

% Controlled varaibles
%--------------------------------------------------------------------------
% Modified code (from L15)
% H0 = [zeros(4,1),eye(4)];
H0 = [zeros(4,2),eye(4)];
%--------------------------------------------------------------------------


h0     = H0 * q;
dh0    = H0 * dq;
dh0_dq = H0;

end

