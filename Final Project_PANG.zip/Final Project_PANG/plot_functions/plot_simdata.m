function plot_simdata(Time,Q,dQ,ddQ,U,Y,dY,F,S,dS,Pcm,P0,P0T,PHR,P1R,P2R,P3R,PHL,P1L,P2L,P3L,save_indicator,folder_name)

if save_indicator==1
    cd Simulation
    mkdir(folder_name)
    cd(folder_name)
end

FS = 30;

% Phase portraits

figure
plot(Q(1,:),dQ(1,:),'LineWidth',1,'Color','k')
hold on
plot(Q(1,1),dQ(1,1),'o','MarkerEdgeColor','k','MarkerSize',7,'MarkerFaceColor','k') ;
xlabel('(rad)','Interpreter','LaTex','FontSize',FS); ylabel('(rad/s)','Interpreter','LaTex','FontSize',FS);
legend('Yaw'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_x = min(Q(1,:));
max_x = max(Q(1,:));
d_x   = 0.1*(max_x-min_x);
min_y = min(dQ(1,:));
max_y = max(dQ(1,:));
d_y   = 0.1*(max_y-min_y);
axis([min_x-d_x max_x+d_x min_y-d_y max_y+d_y])
set(gca,'FontSize',FS/2)
if save_indicator==1
    print('phaseportrait_yaw','-depsc')
end

figure
plot(Q(2,:),dQ(2,:),'LineWidth',1,'Color','k')
hold on
plot(Q(2,1),dQ(2,1),'o','MarkerEdgeColor','k','MarkerSize',7,'MarkerFaceColor','k') ;
xlabel('(rad)','Interpreter','LaTex','FontSize',FS); ylabel('(rad/s)','Interpreter','LaTex','FontSize',FS);
legend('Roll'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_x = min(Q(2,:));
max_x = max(Q(2,:));
d_x   = 0.1*(max_x-min_x);
min_y = min(dQ(2,:));
max_y = max(dQ(2,:));
d_y   = 0.1*(max_y-min_y);
axis([min_x-d_x max_x+d_x min_y-d_y max_y+d_y])
set(gca,'FontSize',FS/2)
if save_indicator==1
    print('phaseportrait_roll','-depsc')
end

figure
plot(Q(3,:),dQ(3,:),'LineWidth',1,'Color','k')
hold on
plot(Q(3,1),dQ(3,1),'o','MarkerEdgeColor','k','MarkerSize',7,'MarkerFaceColor','k') ;
xlabel('(rad)','Interpreter','LaTex','FontSize',FS); ylabel('(rad/s)','Interpreter','LaTex','FontSize',FS);
legend('Pitch'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_x = min(Q(3,:));
max_x = max(Q(3,:));
d_x   = 0.1*(max_x-min_x);
min_y = min(dQ(3,:));
max_y = max(dQ(3,:));
d_y   = 0.1*(max_y-min_y);
axis([min_x-d_x max_x+d_x min_y-d_y max_y+d_y])
set(gca,'FontSize',FS/2)
if save_indicator==1
    print('phaseportrait_pitch','-depsc')
end

figure
plot(Q(4,:),dQ(4,:),'LineWidth',1,'Color','k')
hold on
plot(Q(4,1),dQ(4,1),'o','MarkerEdgeColor','k','MarkerSize',7,'MarkerFaceColor','k') ;
xlabel('(rad)','Interpreter','LaTex','FontSize',FS); ylabel('(rad/s)','Interpreter','LaTex','FontSize',FS);
legend('$q_{KR}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_x = min(Q(4,:));
max_x = max(Q(4,:));
d_x   = 0.1*(max_x-min_x);
min_y = min(dQ(4,:));
max_y = max(dQ(4,:));
d_y   = 0.1*(max_y-min_y);
axis([min_x-d_x max_x+d_x min_y-d_y max_y+d_y])
set(gca,'FontSize',FS/2)
if save_indicator==1
    print('phaseportrait_knee','-depsc')
end

figure
plot(Q(5,:),dQ(5,:),'LineWidth',1,'Color','k')
hold on
plot(Q(5,1),dQ(5,1),'o','MarkerEdgeColor','k','MarkerSize',7,'MarkerFaceColor','k') ;
xlabel('(rad)','Interpreter','LaTex','FontSize',FS); ylabel('(rad/s)','Interpreter','LaTex','FontSize',FS);
legend('$q_{SHR}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_x = min(Q(5,:));
max_x = max(Q(5,:));
d_x   = 0.1*(max_x-min_x);
min_y = min(dQ(5,:));
max_y = max(dQ(5,:));
d_y   = 0.1*(max_y-min_y);
axis([min_x-d_x max_x+d_x min_y-d_y max_y+d_y])
set(gca,'FontSize',FS/2)
if save_indicator==1
    print('phaseportrait_Ship','-depsc')
end

figure
plot(Q(6,:),dQ(6,:),'LineWidth',1,'Color','k')
hold on
plot(Q(6,1),dQ(6,1),'o','MarkerEdgeColor','k','MarkerSize',7,'MarkerFaceColor','k') ;
xlabel('(rad)','Interpreter','LaTex','FontSize',FS); ylabel('(rad/s)','Interpreter','LaTex','FontSize',FS);
legend('$q_{FHR}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_x = min(Q(6,:));
max_x = max(Q(6,:));
d_x   = 0.1*(max_x-min_x);
min_y = min(dQ(6,:));
max_y = max(dQ(6,:));
d_y   = 0.1*(max_y-min_y);
axis([min_x-d_x max_x+d_x min_y-d_y max_y+d_y])
set(gca,'FontSize',FS/2)
if save_indicator==1
    print('phaseportrait_Fhip','-depsc')
end

%--------------------------------------------------------------------------

% Positions

figure
plot(Time,180/pi*Q(1,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg)','Interpreter','LaTex','FontSize',FS);
legend('Yaw'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*Q(1,:));
max_y = max(180/pi*Q(1,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('position_yaw','-depsc')
end

figure
plot(Time,180/pi*Q(2,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg)','Interpreter','LaTex','FontSize',FS);
legend('Roll'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*Q(2,:));
max_y = max(180/pi*Q(2,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('position_roll','-depsc')
end

figure
plot(Time,180/pi*Q(3,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg)','Interpreter','LaTex','FontSize',FS);
legend('Pitch'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*Q(3,:));
max_y = max(180/pi*Q(3,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('position_pitch','-depsc')
end

figure
plot(Time,180/pi*Q(4,:),'LineWidth',1,'Color','k')
hold on
plot(Time,180/pi*Q(7,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg)','Interpreter','LaTex','FontSize',FS);
legend('$q_{KR}$','$q_{KL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*Q(4,:));
max_y = max(180/pi*Q(4,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('position_knee','-depsc')
end

figure
plot(Time,180/pi*Q(5,:),'LineWidth',1,'Color','k')
hold on
plot(Time,180/pi*Q(8,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg)','Interpreter','LaTex','FontSize',FS);
legend('$q_{SHR}$','$q_{SHL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*Q(5,:));
max_y = max(180/pi*Q(5,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('position_Ship','-depsc')
end

figure
plot(Time,180/pi*Q(6,:),'LineWidth',1,'Color','k')
hold on
plot(Time,180/pi*Q(9,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg)','Interpreter','LaTex','FontSize',FS);
legend('$q_{FHR}$','$q_{FHL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*Q(6,:));
max_y = max(180/pi*Q(9,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('position_Fhip','-depsc')
end

%--------------------------------------------------------------------------

% Velocities

figure
plot(Time,180/pi*dQ(1,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg/s)','Interpreter','LaTex','FontSize',FS);
legend('Yaw'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*dQ(1,:));
max_y = max(180/pi*dQ(1,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('velocity_yaw','-depsc')
end


figure
plot(Time,180/pi*dQ(2,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg/s)','Interpreter','LaTex','FontSize',FS);
legend('Roll'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*dQ(2,:));
max_y = max(180/pi*dQ(2,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('velocity_roll','-depsc')
end

figure
plot(Time,180/pi*dQ(3,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg/s)','Interpreter','LaTex','FontSize',FS);
legend('Pitch'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*dQ(3,:));
max_y = max(180/pi*dQ(3,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('velocity_pitch','-depsc')
end

figure
plot(Time,180/pi*dQ(4,:),'LineWidth',1,'Color','k')
hold on
plot(Time,180/pi*dQ(7,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg/s)','Interpreter','LaTex','FontSize',FS);
legend('$\dot{q}_{KR}$','$\dot{q}_{KL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*dQ(4,:));
max_y = max(180/pi*dQ(4,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('velocity_knee','-depsc')
end

figure
plot(Time,180/pi*dQ(5,:),'LineWidth',1,'Color','k')
hold on
plot(Time,180/pi*dQ(8,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg/s)','Interpreter','LaTex','FontSize',FS);
legend('$\dot{q}_{SHR}$','$\dot{q}_{SHL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*dQ(5,:));
max_y = max(180/pi*dQ(5,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('velocity_Ship','-depsc')
end

figure
plot(Time,180/pi*dQ(6,:),'LineWidth',1,'Color','k')
hold on
plot(Time,180/pi*dQ(9,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(deg/s)','Interpreter','LaTex','FontSize',FS);
legend('$\dot{q}_{FHR}$','$\dot{q}_{FHL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(180/pi*dQ(6,:));
max_y = max(180/pi*dQ(9,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('velocity_Fhip','-depsc')
end

%--------------------------------------------------------------------------

% Torques

figure
plot(Time,U(1,:),'LineWidth',1,'Color','k')
hold on
plot(Time,U(4,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(Nm)','Interpreter','LaTex','FontSize',FS);
legend('$u_{KR}$','$u_{KL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(U(1,:));
max_y = max(U(1,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('torque_knee','-depsc')
end

figure
plot(Time,U(2,:),'LineWidth',1,'Color','k')
hold on
plot(Time,U(5,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(Nm)','Interpreter','LaTex','FontSize',FS);
legend('$u_{SHR}$','$u_{SHL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(U(2,:));
max_y = max(U(2,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('torque_Ship','-depsc')
end

figure
plot(Time,U(3,:),'LineWidth',1,'Color','k')
hold on
plot(Time,U(6,:),'LineWidth',1,'Color','r')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(Nm)','Interpreter','LaTex','FontSize',FS);
legend('$u_{FHR}$','$u_{FHL}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(U(3,:));
max_y = max(U(3,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('torque_Fhip','-depsc')
end

%--------------------------------------------------------------------------

% Forces

figure
subplot(211)
plot(Time,F(3,:),'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
ylabel('(N)','Interpreter','LaTex','FontSize',FS);
legend('$F_{z}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(F(3,:));
max_y = max(F(3,:));
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])

subplot(212)
r =  sqrt(F(1,:).^2+F(2,:).^2)./F(3,:);
plot(Time,r,'LineWidth',1,'Color','k')
xlabel('Time (s)','Interpreter','LaTex','FontSize',FS); 
legend('$\sqrt{F_{x}^{2}+F_{y}^{2}}/F_{z}$'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
min_y = min(r);
max_y = max(r);
d_y   = 0.1*(max_y-min_y);
axis([0 Time(end) min_y-d_y max_y+d_y])
if save_indicator==1
    print('GRF','-depsc')
end

%--------------------------------------------------------------------------

if save_indicator==1
    cd ..
end

end

