function Plot_Robustness_Data(d,Vcm1,Vcm2,two_sim)

FS = 40;
LW = 3;
BW = 0.2;
MS = 15;
N  = length(d);
d  = 180/pi*d;

figure
subplot(411)
%bar(d,BW)
stem([1:N],d,'square','filled','MarkerSize',MS,'LineWidth',LW,'Color','k')
%xlabel('Step Number','Interpreter','LaTex','FontSize',FS);
ylabel('$d[k]$','Interpreter','LaTex','FontSize',FS);
min_x = 1;
max_x = N;
min_y = min(d);
max_y = max(d);
d_y   = 0.1*(max_y-min_y);
axis([min_x max_x min_y-d_y max_y+d_y]);
set(gca,'fontsize',0.8*FS)

%figure
subplot(412)
hold on
stem([1:N],Vcm1(1,:),'filled','MarkerSize',MS,'LineWidth',LW,'Color','b')
if two_sim == 1
    stem([1:N],Vcm2(1,:),':diamondr','filled','MarkerSize',MS,'LineWidth',LW,'Color','r')
end  
%xlabel('Step Number','Interpreter','LaTex','FontSize',FS);
ylabel('$\delta v_{\textrm{cm}}^{x}[k]$','Interpreter','LaTex','FontSize',FS);
legend('Nominal','BMI Optimized'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
%legend('Nominal','BMI Optimized'); lh = legend;set(lh,'Interpreter','LaTex','FontSize',FS);
set(gca,'fontsize',0.8*FS)
min_y1 = min(Vcm1(1,:));
max_y1 = max(Vcm1(1,:));
min_y2 = min(Vcm2(1,:));
max_y2 = max(Vcm2(1,:));
min_y  = min(min_y1,min_y2);
max_y  = max(max_y1,max_y2);
d_y   = 0.1*(max_y-min_y);
axis([min_x max_x min_y-d_y max_y+d_y]);

%figure
subplot(413)
hold on
stem([1:N],Vcm1(2,:),'filled','MarkerSize',MS,'LineWidth',LW,'Color','b')
if two_sim == 1
    stem([1:N],Vcm2(2,:),':diamondr','filled','MarkerSize',MS,'LineWidth',LW,'Color','r')
end
ylabel('$\delta v_{\textrm{cm}}^{y}[k]$','Interpreter','LaTex','FontSize',FS);
set(gca,'fontsize',0.8*FS)
min_y1 = min(Vcm1(2,:));
max_y1 = max(Vcm1(2,:));
min_y2 = min(Vcm2(2,:));
max_y2 = max(Vcm2(2,:));
min_y  = min(min_y1,min_y2);
max_y  = max(max_y1,max_y2);
d_y   = 0.1*(max_y-min_y);
axis([min_x max_x min_y-d_y max_y+d_y]);

%figure
subplot(414)
hold on
stem([1:N],Vcm1(3,:),'filled','MarkerSize',MS,'LineWidth',LW,'Color','b')
if two_sim == 1
    stem([1:N],Vcm2(3,:),':diamondr','filled','MarkerSize',MS,'LineWidth',LW,'Color','r')
end
xlabel('Step Number','Interpreter','LaTex','FontSize',FS);
ylabel('$\delta v_{\textrm{cm}}^{z}[k]$','Interpreter','LaTex','FontSize',FS);
set(gca,'fontsize',0.8*FS)
min_y1 = min(Vcm1(3,:));
max_y1 = max(Vcm1(3,:));
min_y2 = min(Vcm2(3,:));
max_y2 = max(Vcm2(3,:));
min_y  = min(min_y1,min_y2);
max_y  = max(max_y1,max_y2);
d_y   = 0.1*(max_y-min_y);
axis([min_x max_x min_y-d_y max_y+d_y]);

end

