%% Animation
clc;clear;
close all
%--------------------------------------------------------------------------
            
load('myIC')


M = 5;
AT                = 1e-6; % Absolute tolerance for ODE solver
RT                = 1e-3; % Relative tolerance for ODE solver
RF                = 1;    % Refine factor for ODE solver
%--------------------------------------------------------------------------
% save('Data','t_stance','q_stance','dq_stance','ddq_stance','u_stance','u_stance','y_stance','dy_stance','F_stance','s_stance','ds_stance','p_swing','dp_swing');

% plot moving stick man
% figure (1)
% axis equal
% grid on
% set(gcf,'Position',[20 50 1400 600])


a2 = X(13:16);
a3 = X(17:20);
x_offset = 0;
t_stance_stored = [];
p_swing_stored = [];
q_stance_stored = [];
dq_stance_stored = [];
u_stance_stored = [];
y_stance_stored = [];
s_stance_stored = [];
theta_stored = [];
dp_swing_stored = [];
dp_swing_stored = [];
F_stance_stored = [];
for step = 1:10
    
    [Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(X,M);
    [t_stance,q_stance,dq_stance,ddq_stance,u_stance,y_stance,dy_stance,F_stance,s_stance,ds_stance,p_swing,dp_swing,theta] = solve_stance_ODE(Xs_plus,a_matrix,theta_plus,theta_minus,AT,RT,RF);
    
    % store variables
    if (step == 1)
        t_stance_stored = [t_stance_stored;t_stance];
    else
        t_stance_stored = [t_stance_stored;t_stance + t_stance_stored(end)];
    end
    q_stance_stored = [q_stance_stored,q_stance];
    dq_stance_stored = [dq_stance_stored,dq_stance];
    u_stance_stored = [u_stance_stored, u_stance];
    y_stance_stored = [y_stance_stored, y_stance];
    s_stance_stored = [s_stance_stored; s_stance];
    theta_stored = [theta_stored, theta];
    p_swing_stored = [p_swing_stored, p_swing];
    dp_swing_stored = [dp_swing_stored,dp_swing];
    F_stance_stored = [F_stance_stored,F_stance];
    
    %plot 1 step
%     for k = 1:length(t_stance)
%         joint_pos = FK_hw31(q_stance(:,k));
%         pcm = pcm_hw31(q_stance(:,k));
%         p0(:,k) = joint_pos(:,1);
%         pcmT(:,k) = joint_pos(:,2);
%         pHst(:,k) = joint_pos(:,3);
%         pHsw(:,k) = joint_pos(:,4);
%         pcmST(:,k) = joint_pos(:,5);
%         pcmSW(:,k) = joint_pos(:,6);
%         p1(:,k) = joint_pos(:,7);
%         p2(:,k) = joint_pos(:,8);
%         
%         x1 = [p0(1,k) ; pcmT(1,k)];
%         y1 = [p0(2,k) ; pcmT(2,k)];
%         z1 = [p0(3,k) ; pcmT(3,k)];
%         
%         x2 = [p0(1,k); pHst(1,k)];
%         y2 = [p0(2,k); pHst(2,k)];
%         z2 = [p0(3,k); pHst(3,k)];
%         
%         x3 = [p0(1,k); pHsw(1,k)];
%         y3 = [p0(2,k); pHsw(2,k)];
%         z3 = [p0(3,k); pHsw(3,k)];
%         
%         x4 = [pHst(1,k); p1(1,k)];
%         y4 = [pHst(2,k); p1(2,k)];
%         z4 = [pHst(3,k); p1(3,k)];
%         
%         x5 = [pHsw(1,k); p2(1,k)];
%         y5 = [pHsw(2,k); p2(2,k)];
%         z5 = [pHsw(3,k); p2(3,k)];
%         
%         clf;
%         hold on
%         view(100,20)
% %          view(180,20)
% 
%         xlabel('X(m)')
%         ylabel('Y(m)')
%         zlabel('Z(m)')
%         axis equal
%         grid on
% %         xlim([-1.5 ,1.5])
% %         ylim([0 1.5])
%         plot3(x1,y1,z1,'LineWidth',3,'Color','b','linewidth',6);
%         plot3(x2,y2,z2,'LineWidth',3,'Color','g','linewidth',6);
%         plot3(x3,y3,z3,'LineWidth',3,'Color','r','linewidth',6);
%         plot3(x4,y4,z4,'LineWidth',3,'Color','c','linewidth',6);
%         plot3(x5,y5,z5,'LineWidth',3,'Color','m','linewidth',6);
%         scatter3(pcm(1),pcm(2),pcm(3),100,'filled','MarkerFaceColor','k')
%         plot_xyground(-0.5,0.5,-0.5,0.5)
%         legend('Torso','Stance hip','Swing hip','stance leg','swing leg','CoM','Ground')
%         time_str = sprintf(' t = %.2f ',t_stance(k));
%         title(time_str)
%         drawnow 
%         
%     end
    
    %extract the last q and dq
    q_stance_end = q_stance(:,end);
    dq_stance_end = dq_stance(:,end);
    X = [q_stance_end; dq_stance_end;a2;a3];
end
%% plot results
if (1)
figure('Name','Phase Portraits')
for k = 1:6
    subplot(3,2,k)
    plot(q_stance_stored(k,:)* 180/pi,dq_stance_stored(k,:) * 180/pi)
    ylabel('Joint velocities(deg/s)')
    xlabel('Joint angles (deg)')
    grid on
    switch k
        case 1
            title('q_y')
        case 2
            title('q_x')
        case 3
            title('q_s_t_R')    
        case 4
            title('q_s_t_R')    
        case 5
            title('q_s_w_R') 
        case 6
            title('q_s_w_P') 
    end
end

figure('Name','CoM Velocity')
subplot(3,1,1)
plot(t_stance_stored,dp_swing_stored(1,:))
grid on
legend('X direction COM velocity')
ylabel('Robot Velocity (m/s)')
xlabel('Time (s)')
subplot(3,1,2)
plot(t_stance_stored,dp_swing_stored(2,:))
grid on
legend('y direction COM velocity')
ylabel('Robot Velocity (m/s)')
xlabel('Time (s)')
subplot(3,1,3)
plot(t_stance_stored,dp_swing_stored(3,:))
grid on
legend('z direction COM velocity')
ylabel('Robot Velocity (m/s)')
xlabel('Time (s)')

figure('Name','Phasing variable')
plot(t_stance_stored,theta_stored)
grid on
ylabel('Phasing variable')
xlabel('Time (s)')

figure('Name','Joint angles over steps')
set(gca,'fontsize',14) 
subplot(4,1,1)
plot(t_stance_stored,q_stance_stored(1,:) * 180/pi)
grid on
legend('qy')
ylabel('Joint Angle (deg)')
xlabel('Time (s)')
title('Torso Row')
subplot(4,1,2)
plot(t_stance_stored,q_stance_stored(2,:) * 180/pi)
grid on
legend('qx')
ylabel('Joint Velocity ((deg)')
xlabel('Time (s)')
title('Torso Pitch')
subplot(4,1,3)
plot(t_stance_stored,q_stance_stored([3,5],:) * 180/pi)
grid on
legend('qst_r','qsw_r')
ylabel('Joint Velocity (deg)')
xlabel('Time (s)')
title('Leg Row')
subplot(4,1,4)
plot(t_stance_stored,q_stance_stored([4,6],:) * 180/pi)
grid on
legend('qst_p','qsw_p')
ylabel('Joint Velocity (deg)')
xlabel('Time (s)')
title('Leg Pitch')

figure('Name','Joint velocities over steps')
set(gca,'fontsize',14) 
subplot(4,1,1)
plot(t_stance_stored,dq_stance_stored(1,:) * 180/pi)
grid on
legend('dqy')
ylabel('Joint Velocity (deg)')
xlabel('Time (s)')
title('Torso Row')
subplot(4,1,2)
plot(t_stance_stored,dq_stance_stored(2,:) * 180/pi)
grid on
legend('dqx')
ylabel('Joint Velocity ((deg/s)')
xlabel('Time (s)')
title('Tprsp Pitch')
subplot(4,1,3)
plot(t_stance_stored,dq_stance_stored([3,5],:) * 180/pi)
grid on
legend('dqst_r','dqsw_r')
ylabel('Joint Velocity (deg/s)')
xlabel('Time (s)')
title('Leg Row')
subplot(4,1,4)
plot(t_stance_stored,dq_stance_stored([4,6],:) * 180/pi)
grid on
legend('dqst_p','dqsw_p')
ylabel('Joint Angle (deg/s)')
xlabel('Time (s)')
title('Leg Pitch')

figure('Name','GRF')
for k = 1:3
    subplot(3,1,k)
plot(t_stance_stored,F_stance_stored(k,:))
grid on
ylabel('Stance Leg GRF (N)')
xlabel('Time (s)')
    switch k
        case 1
            legend('Fx')
        case 2
            legend('Fy')
        case 3
            legend('Fz')    
    end
end

figure('Name','Swing Leg Position')
hold on
for k = 1:3
    subplot(3,1,k)
    plot(t_stance_stored,p_swing_stored(k,:))
    grid on
    xlabel('Time (s)')
    ylabel('Position (m)')
% legend('Swing leg x pos','Swing leg y pos','Swing leg z pos')
    switch k
        case 1
            legend('Swing leg x pos')
        case 2
            legend('Swing leg y pos')
        case 3
            legend('Swing leg z pos')    
    end
end
hold off
% figure('Name','output')
% plot(t_stance_stored,y_stance_stored)
% legend('Output')
% grid on

figure('Name','Control input')
for k = 1:4
    subplot(4,1,k)
    plot(t_stance_stored,u_stance_stored(k,:))
    grid on
    ylabel('Input (N/m)')
    xlabel('Time (s)')
    switch k
        case 1
            legend('stance row control input')
        case 2
            legend('stance pitch control input')
        case 3
            legend('swing row control input')
        case 4
            legend('swing pitch control input')
    end
end

figure('Name','Scaled phasing variable')
plot(t_stance_stored,s_stance_stored)
grid on
ylabel('Sacled phasing variable')
xlabel('Time (s)')
end
