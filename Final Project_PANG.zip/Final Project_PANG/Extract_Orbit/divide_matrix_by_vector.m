function [dQ_ds] = divide_matrix_by_vector(dQ_dt,ds_dt)

[m,n] = size(dQ_dt);
for k=1:n
    dQ_ds(:,k) = dQ_dt(:,k)/ds_dt(k);
end % end od for

end

