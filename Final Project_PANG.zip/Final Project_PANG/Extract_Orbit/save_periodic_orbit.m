
% Extract periodic orbit
bez_order = 9;
[alpha_Rstance,dalpha_Rstance,beta_Rstance,gamma_Rstance,dgamma_Rstance,X_Rstance,eta_Rstance,U_Rstance,time_Rstance,s_Rstance] = Extract_Periodic_Orbit_Main(Time,Leg,S,dS,Q,dQ,YAW_HR,YAW_HL,ROLL_HR,ROLL_HL,dYAW_HR,dYAW_HL,dROLL_HR,dROLL_HL,U,1,theta_plus,theta_minus,bez_order);
% [alpha_Rstance,dalpha_Rstance,beta_Rstance,gamma_Rstance,dgamma_Rstance,X_Rstance,eta_Rstance,U_Rstance,time_Rstance,s_Rstance] = Extract_Periodic_Orbit_Main(Time,Leg,IMU_S,IMu_dS,Q,dQ,YAW_HR,YAW_HL,ROLL_HR,ROLL_HL,dYAW_HR,dYAW_HL,dROLL_HR,dROLL_HL,U,1,IMU_theta_plus,IMU_theta_minus,bez_order);


%%
% Check the accuracy of the regression
Q_Rstance = X_Rstance(1:9,:);
Q_Rstance_app   = [];
eta_Rstance_app = [];
U_Rstance_app   = [];
n = length(time_Rstance);
for k=1:n
    Q_Rstance_temp       = bezier(alpha_Rstance,s_Rstance(k));
    eta_Rstance_temp     = bezier(gamma_Rstance,s_Rstance(k));
    U_Rstance_temp       = bezier(beta_Rstance,s_Rstance(k));
    Q_Rstance_app(:,k)   = Q_Rstance_temp;
    eta_Rstance_app(:,k) = eta_Rstance_temp;
    U_Rstance_app(:,k)   = U_Rstance_temp;
end % end of for

% plot
figure

subplot(331)
plot(s_Rstance,Q_Rstance(1,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(1,:),'LineWidth',1,'Color','r')
subplot(332)
plot(s_Rstance,Q_Rstance(2,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(2,:),'LineWidth',1,'Color','r')
subplot(333)
plot(s_Rstance,Q_Rstance(3,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(3,:),'LineWidth',1,'Color','r')
subplot(334)
plot(s_Rstance,Q_Rstance(4,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(4,:),'LineWidth',1,'Color','r')
subplot(335)
plot(s_Rstance,Q_Rstance(5,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(5,:),'LineWidth',1,'Color','r')
subplot(336)
plot(s_Rstance,Q_Rstance(6,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(6,:),'LineWidth',1,'Color','r')
subplot(337)
plot(s_Rstance,Q_Rstance(7,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(7,:),'LineWidth',1,'Color','r')
subplot(338)
plot(s_Rstance,Q_Rstance(8,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(8,:),'LineWidth',1,'Color','r')
subplot(339)
plot(s_Rstance,Q_Rstance(9,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,Q_Rstance_app(9,:),'LineWidth',1,'Color','r')

figure

subplot(221)
plot(s_Rstance,eta_Rstance(1,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,eta_Rstance_app(1,:),'LineWidth',1,'Color','r')
subplot(222)
plot(s_Rstance,eta_Rstance(2,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,eta_Rstance_app(2,:),'LineWidth',1,'Color','r')
subplot(223)
plot(s_Rstance,eta_Rstance(3,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,eta_Rstance_app(3,:),'LineWidth',1,'Color','r')
subplot(224)
plot(s_Rstance,eta_Rstance(4,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,eta_Rstance_app(4,:),'LineWidth',1,'Color','r')

figure

subplot(321)
plot(s_Rstance,U_Rstance(1,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,U_Rstance_app(1,:),'LineWidth',1,'Color','r')
subplot(322)
plot(s_Rstance,U_Rstance(2,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,U_Rstance_app(2,:),'LineWidth',1,'Color','r')
subplot(323)
plot(s_Rstance,U_Rstance(3,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,U_Rstance_app(3,:),'LineWidth',1,'Color','r')
subplot(324)
plot(s_Rstance,U_Rstance(4,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,U_Rstance_app(4,:),'LineWidth',1,'Color','r')
subplot(325)
plot(s_Rstance,U_Rstance(5,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,U_Rstance_app(5,:),'LineWidth',1,'Color','r')
subplot(326)
plot(s_Rstance,U_Rstance(6,:),'LineWidth',1,'Color','k')
hold on
plot(s_Rstance,U_Rstance_app(6,:),'LineWidth',1,'Color','r')