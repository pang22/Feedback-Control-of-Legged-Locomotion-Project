function [qs_plus,dqs_plus,F_imp,dz_plus] = impact_map(qs_minus,dqs_minus,leg)

% This function returns the position and velocity just after the impact.
%
% Inputs:
%
% qs_minus:  9-dim position just before the impact
% dqs_minus: 9-dim velocity just before the impact
% leg:       stance phase indicator (0 if the previous stance phase was right and
% 1 if the previous stance phase was left)
%
% Outputs:
%
% qs_plus:  9-dim position just after the impact
% dqs_plus: 9-dim velocity just after the impact
% F_imp:    4-dim Lagrange multipliers at the impact model. The first three
% rows correspond to the impulsive force, whereas the last row is the
% impulsive torque, i.e., F_imp = [Fx Fy Fz Mz]'.

% For more details see Eq. (6) of

% K. Akbari Hamed and J. W. Grizzle, �Event-based stabilization of periodic
% orbits for underactuated 3D bipedal robots with left-right symmetry,�
% IEEE Transactions on Robotics, vol. 30, issue 2, pp. 365-381, April 2014
% http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=6663683

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Extended coordiantes
qe_minus  = [qs_minus;  zeros(3,1)];
dqe_minus = [dqs_minus; zeros(3,1)];

%--------------------------------------------------------------------------
% Modified code
% qe_minus  = [qs_minus;  zeros(2,1)];
% dqe_minus = [dqs_minus; zeros(2,1)];
%--------------------------------------------------------------------------

% Impact model
if leg==0 % right to left switching (impcat on the left leg)
%     [D,E]= Cfcn_Robot_ImpactModel_StanceRight_Parametric(qe_minus); 
    
    %--------------------------------------------------------------------------
    % Modified code
%     D = extended_inertia_Matrix(qe_minus,robot_params);
%     E = extended_swing_Jacobian(qe_minus,robot_params);
    %--------------------------------------------------------------------------
    D = De_hw31(qe_minus);
    E = Je_hw31(qe_minus);
else % left to right switching (impact on the right leg)
%     [D,E]= Cfcn_Robot_ImpactModel_StanceLeft_Parametric(qe_minus); %Do I
%     modified this?
end % end of if

A   = [D -E'; E zeros(3,3)];
RHS = [D*dqe_minus; zeros(3,1)];
X   = A\RHS; %same of inv(A)

%--------------------------------------------------------------------------
% Modified code (From L5)
% A   = [D -E'; E zeros(2,2)];
% RHS = [D*dqe_minus; zeros(2,1)];
% X   = A\RHS; %same of inv(A)
%--------------------------------------------------------------------------



%--------------------------------------------------------------------------
% Modified code (from L5
% dqe_plus = X(1:7);
% F_imp    = X(8:end); % F is 2-dim
dqe_plus = X(1:9);
F_imp    = X(10:end); % F is 3-dim
%--------------------------------------------------------------------------
qs_plus  = qs_minus; % continuity of position

% if 1
%     % do nothing
% else % plannar impact
%     qs_plus(1) = 0; qs_plus(2) = 0; qs_plus(6) = 0; qs_plus(9) = 0; %DO I KEEP THIS?
% end

% dqs_plus = dqe_plus(1:9);
% dz_plus  = dqe_plus(12);

%--------------------------------------------------------------------------
% Modified code
% dqs_plus = dqe_plus(1:5);
% dz_plus  = dqe_plus(7);
dqs_plus = dqe_plus(1:6);
dz_plus  = dqe_plus(end);
%--------------------------------------------------------------------------
end

