clc;clear;close all
syms qy qx qSTH_R qSTH_P qSWH_R qSWH_P real
syms dqy dqx dqSTH_R dqSTH_P dqSWH_R dqSWH_P real

syms xT yT zT real
q = [qy;... torso absolute row angle
     qx;... torso absolute pitch angle
     qSTH_R;...stance hip roll angle
     qSTH_P;...stance hip pitch angle
     qSWH_R;...swing hip roll angle
     qSWH_P];...swing hip pitch angle

     
dq = [dqy;... torso row velocity
     dqx;... torso pitch velocity
     dqSTH_R;...stance hip roll velocity
     dqSTH_P;...stance hip pitch velocity
     dqSWH_R;...swing hip roll velocity
     dqSWH_P];...swing hip pitch velocity

% The yaw angle and velocity is asuumed to be zero
qz = 0;
dqz = 0;

% -------------------------------------------------------------------------
% Robot parameters
g = 9.81; % gravitational constant (m/s^2)
W = 0.15; % hip width (m)
L1 = 0.55;% leg 1 (stance leg) legnth (m)
L2 = 0.05;% leg 2 (swing leg) length  (m)
m1 = 1.75;% leg mass (kg)
m2 = 5.5; % torso mass (kg)
M = 9.0;  % total mass (kg)

robot_params = [g; W; L1; L2; m1; m2; M]; % from Table 1 of the Shih Paper
% -------------------------------------------------------------------------

% 3 basic fundemental rotation matrix (from L20)
Rx = @ (theta) [1 0 0 ; 0 cos(theta) -sin(theta); 0 sin(theta) cos(theta)];
Ry = @ (theta) [cos(theta) 0 sin(theta); 0 1 0 ; -sin(theta) 0 cos(theta)];
Rz = @ (theta) [cos(theta) -sin(theta) 0; sin(theta) cos(theta) 0; 0 0 1];

% Torso rotation matrix and angular velocity (from L23)
% w0 = zeros(3,1); % torso angular velocity

% w0 = w0 + R0(:,2)*dqy;
R0 = eye(3)*Ry(qy)*Rx(qx);



% rotation matrices
% % R3 = R0 * Rx(qSTH_R);       % rotation from torso to stance row axis 
% R1 = R0 * Rx(qSTH_R) * Ry(qSTH_P);    % rotation from torso to stance pitch axis 
% 
% % R4 =  R0* Rx(-qSWH_R);        % rotation from torso to swing row axis
% R2 =  R0* Rx(-qSWH_R) * Ry(qSWH_P);    % rotation from torso to swing pitch axis 

R1 = R0 * Rx(qSTH_P) * Ry(qSTH_R);    % rotation from torso to stance pitch axis 

% R4 =  R0* Rx(-qSWH_R);        % rotation from torso to swing row axis
R2 =  R0* Rx(qSWH_P) * Ry(-qSWH_R);    % rotation from torso to swing pitch axis 

% Joint, CoM and feet position
p0 = [xT; yT; zT]; % Center Hip (symbolic) 
pcmT = p0 + R0 * [0; 0; L2]; % Top torso

% pHst = p0 + R3 * [0; W/2; 0]; % Stance leg hip
% pHsw = p0 + R4 * [0; -W/2; 0];% Swing  leg hip
pHst = p0 + R0 * [W/2; 0; 0]; % Stance leg hip
pHsw = p0 + R0 * [W/2; 0; 0];% Swing  leg hip

% pHst = p0 +  [0; W/2; 0]; % Stance leg hip
% pHsw = p0 +  [0; -W/2; 0];% Swing  leg hip

pcmST = pHst + R1 * [0; 0; L1/2];% stance leg CoM 
pcmSW = pHsw + R2 * [0; 0; L1/2];% swing leg CoM 


p1 =  pHst + R1 * [0; 0; L1];% stance leg end 
p2 =  pHsw + R2 * [0; 0; L1];% swing leg end 

%simplify and vpa
pcmT = simplify(pcmT); pcmT = vpa(pcmT);
pHst = simplify(pHst); pHst = vpa(pHst);
pHsw = simplify(pHsw); pHsw = vpa(pHsw);
pcmST = simplify(pcmST); pcmST = vpa(pcmST);
pcmSW = simplify(pcmSW); pcmSW = vpa(pcmSW);
p1 = simplify(p1); p1 = vpa(p1);
p2 = simplify(p2); p2 = vpa(p2);

eqn = p1 ==zeros(3,1);
sol = solve(eqn,xT,yT,zT);
xT = sol.xT;
yT = sol.yT;
zT = sol.zT;
% -------------------------------------------------------------------------
% Resolve positions
p0 = [xT; yT; zT]; % Center Hip (new) 
pcmT = p0 + R0 * [0; 0; L2]; % Top torso

pHst = p0 + R0 * [W/2; 0; 0]; % Stance leg hip
pHsw = p0 + R0 * [-W/2; 0; 0];% Swing  leg hip

pcmST = pHst + R1 * [0; 0; L1/2];% stance leg CoM 
pcmSW = pHsw + R2 * [0; 0; L1/2];% swing leg CoM 
p1 =  pHst + R1 * [0; 0; L1];% stance leg end 
p2 =  pHsw + R2 * [0; 0; L1];% swing leg end 
%simplify and vpa
p0 = simplify(p0); p0 = vpa(p0); % Center Hip (new) 
pcmT = simplify(pcmT); pcmT = vpa(pcmT);
pHst = simplify(pHst); pHst = vpa(pHst);
pHsw = simplify(pHsw); pHsw = vpa(pHsw);
pcmST = simplify(pcmST); pcmST = vpa(pcmST);
pcmSW = simplify(pcmSW); pcmSW = vpa(pcmSW);
p1 = simplify(p1); p1 = vpa(p1);
p2 = simplify(p2); p2 = vpa(p2);
% -------------------------------------------------------------------------
%% Generate phasing variable and its derivative
theta = atan2(xT,zT);
dtheta = jacobian(theta,q) * dq;
dtheta_dq = jacobian(theta,q);

matlabFunction(theta,dtheta_dq, 'vars', {q}, 'file', 'phasing_variable_hw31', 'Optimize', false);
%% Generate forward kinematics
matlabFunction([p0,pcmT,pHst,pHsw,pcmST,pcmSW,p1,p2], 'vars', {q}, 'file', 'FK_hw31', 'Optimize', false);
%% Jacobian and linear velocity
vcmT = jacobian(pcmT,q) * dq;   vcmT =  simplify(vcmT);  vcmT =  vpa(vcmT);
vcmST = jacobian(pcmST,q) * dq; vcmST = simplify(vcmST); vcmST = vpa(vcmST);
vcmSW = jacobian(pcmSW,q) * dq; vcmSW = simplify(vcmSW); vcmSW = vpa(vcmSW);
%% Kinetic energy and Mass-inertia matrix
K = 1/2 * m2 * (vcmT.') * vcmT +...
    1/2 * m1 * (vcmST.') * vcmST +...
    1/2 * m1 * (vcmSW.') * vcmSW;
K = vpa(simplify(K));
dK_dqdot = jacobian(K,dq);
D = vpa(simplify(jacobian(dK_dqdot,dq)));
%% CoM of the whole robot
Mtotal = 2 * m1 + m2;
pcm = (m1 * pcmSW + m1 * pcmST + m2 * pcmT) / Mtotal;

J_robot = jacobian(pcm,q); J_robot = vpa(simplify(J_robot));
V_robot = J_robot * dq;
V_robot = vpa(simplify(V_robot));
matlabFunction(pcm, 'vars', {q}, 'file', 'pcm_hw31', 'Optimize', false);
%% Potential energy and gravity term G
V = Mtotal * g * pcm(3);
G = vpa(simplify(jacobian(V,q).'));
%% Coriolis and centrifugal term Cdq
C = 0 * D;
for k=1:length(q)
    for j=1:length(q)
        C(k,j)=0;
        for i=1:length(q)
            C(k,j)=C(k,j)+(1/2)*(diff(D(k,j),q(i))+diff(D(k,i),q(j))-diff(D(i,j),q(k)))*dq(i);
        end
    end
end
Cdq = C*dq;
Cdq = simplify(Cdq);
%% Input matrix B
q_actuated = q(3:6);
B = jacobian(q_actuated,q)';
%% Generate dynamic terms function
matlabFunction(D, 'vars', {q}, 'file', 'D_hw31', 'Optimize', false);
matlabFunction(Cdq, 'vars', {q,dq}, 'file', 'Cdq_hw31', 'Optimize', false);
matlabFunction(G, 'vars', {q}, 'file', 'G_hw31', 'Optimize', false);
matlabFunction(B, 'vars', {q}, 'file', 'B_hw31', 'Optimize', false);
matlabFunction(V_robot, 'vars', {q,dq}, 'file', 'CoMVel_hw31', 'Optimize', false);
%% Impact dynamics
syms x y z real
syms dx dy dz real

% Extended joint angle and joint velocity
qe = [q; x; y; z];
dqe = [dq; dx; dy; dz];

p0e = [xT; yT; zT] + [x; y; z]; % Center Hip (new) 
pcmTe = p0e + R0 * [0; 0; L2]; % Top torso
pHste = p0e + R0 * [W/2; 0; 0]; % Stance leg hip
pHswe = p0e + R0 * [-W/2;0; 0];% Swing  leg hip
pcmSTe = pHste + R1 * [0; 0; L1/2];% stance leg CoM 
pcmSWe = pHswe + R2 * [0; 0; L1/2];% swing leg CoM 
p1e =  pHste + R1 * [0; 0; L1];% stance leg end 
p2e =  pHswe + R2 * [0; 0; L1];% swing leg end 

matlabFunction([p0e,pcmTe,pHste,pHswe,pcmSTe,pcmSWe,p1e,p2e], 'vars', {qe}, 'file', 'FKe_hw31', 'Optimize', false);
%simplify and vpa

p0e = simplify(p0e); p0e = vpa(p0e); % Center Hip (new) 
pcmTe = simplify(pcmTe); pcmTe = vpa(pcmTe);
pHste = simplify(pHste); pHste = vpa(pHste);
pHswe = simplify(pHswe); pHswe = vpa(pHswe);
pcmSTe = simplify(pcmSTe); pcmSTe = vpa(pcmSTe);
pcmSWe = simplify(pcmSWe); pcmSWe = vpa(pcmSWe);
p1e = simplify(p1e); p1e = vpa(p1e);
p2e = simplify(p2e); p2e = vpa(p2e);

vcmTe = jacobian(pcmTe,qe) *   dqe; vcmTe =  vpa(simplify(vcmTe)); 
vcmSTe = jacobian(pcmSTe,qe) * dqe; vcmSTe = vpa(simplify(vcmSTe)); 
vcmSWe = jacobian(pcmSWe,qe) * dqe; vcmSWe = vpa(simplify(vcmSWe)); 

Ke = 1/2 * m2 * (vcmTe.') * vcmTe +...
    1/2 * m1 * (vcmSTe.') * vcmSTe +...
    1/2 * m1 * (vcmSWe.') * vcmSWe;
Ke = vpa(simplify(Ke));
dKe_dqdot = jacobian(Ke,dqe);
De = vpa(simplify(jacobian(dKe_dqdot,dqe)));

% Extended Coriolis and centrifugal terms
Ce = 0 * De; %C has the same dimension as D
N = length(qe);
% 2 for loop to fill the rows and cols of C matrix, the i for loop is to
% grab the element from q
for k=1:N
    for j=1:N
        sum = 0*g; 
        for i=1:N
            sum = sum + 1/2*(diff(De(k,j),qe(i)) + diff(De(k,i),qe(j)) - diff(De(i,j),qe(k)))*dqe(i);
        end
        Ce(k,j) = sum;
    end
end
Cedq = Ce*dqe;
Cedq = simplify(Cedq);

% Input matrix B
qe_actuated = qe(3:6);
Be = jacobian(qe_actuated,qe).';

Ge = jacobian(V,qe).';

% extended jacobian at the swing leg
Je = vpa(simplify(jacobian(p2e,qe)));
%% Generate De, Je function
matlabFunction(De, 'vars', {qe}, 'file', 'De_hw31', 'Optimize', false);
matlabFunction(Je, 'vars', {qe}, 'file', 'Je_hw31', 'Optimize', false);
matlabFunction(Cedq, 'vars', {qe,dqe}, 'file', 'Cedq_hw3', 'Optimize', false);
matlabFunction(Be, 'vars', {qe}, 'file', 'Be_hw31', 'Optimize', false);
matlabFunction(Ge, 'vars', {qe}, 'file', 'Ge_hw31', 'Optimize', false);