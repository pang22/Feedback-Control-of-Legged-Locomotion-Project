function [ddqs,F] = stance_phase_dynamics(qs,dqs,u,leg)

% This function generates the acceleration and GRF during the stance
% phases.

% ddqs: 9-dim acceleration
% F:    3-dim GRF
%--------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
% Modified code
[D,H,B,Cdq,G] = stance_phase_dynamic_terms(qs,dqs,leg);

%from L4
ddqs = -inv(D)*(Cdq+G) + inv(D)*B*u;
% ddqe = [ddqs;0;0];
ddqe = [ddqs;0;0;0];

% Extend the q and dq
% p0 = [0;0];
% qe  = [qs;p0];
% dqe = [dqs;[0;0]];
p0 = [0;0;0];
qe  = [qs;p0];
dqe = [dqs;[0;0;0]];

De = De_hw31(qe);
Cedq = Cedq_hw3(qe,dqe);
Ge = Ge_hw31(qe);
Be = Be_hw31(qe);
Je = Je_hw31(qe);

%Compute GRF (from L17) 
% ddqe_F = inv([De,-transpose(Je);Je, zeros(2,2)]) * [Be * u - Cedq - Ge; zeros(2,1)];
ddqe_F = inv([De,-transpose(Je);Je, zeros(3,3)]) * [Be * u - Cedq - Ge; zeros(3,1)];
% F = ddqe_F(8:9);
F = ddqe_F(10:12);

% RHS = De * ddqe + Cedq + Ge;
% F = Je*(RHS - Be * u);
% from L4



end

