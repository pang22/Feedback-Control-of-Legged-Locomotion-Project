function [D,H,B,Cdq,G] = stance_phase_dynamic_terms(qs,dqs,leg)

% This function generates the dyanmic terms during the stance
% phases.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------------------------------------------------------
% Modified code
% D = inertia_Matrix(qs,robot_params);
% B = input_matrix(qs,robot_params);
% G = gravity_terms(qs,robot_params);
% Cdq = Coriolis_centrifugal_terms(qs,dqs,robot_params);

D = D_hw31(qs);
B = B_hw31(qs);
G = G_hw31(qs);
Cdq = Cdq_hw31(qs,dqs);

H = Cdq + G; %From L13
%--------------------------------------------------------------------------


end

