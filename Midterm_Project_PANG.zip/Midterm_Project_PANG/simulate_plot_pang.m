%% Animation
% clc;clear;
%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote)
%link lengths
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
            
% load myIC_v1_1.mat
load myIC

M = 5;
AT                = 1e-6; % Absolute tolerance for ODE solver
RT                = 1e-3; % Relative tolerance for ODE solver
RF                = 1;    % Refine factor for ODE solver
%--------------------------------------------------------------------------
% save('Data','t_stance','q_stance','dq_stance','ddq_stance','u_stance','u_stance','y_stance','dy_stance','F_stance','s_stance','ds_stance','p_swing','dp_swing');
% plot moving stick man
figure (1)
axis equal
grid on


a2 = X(11:14);
a3 = X(15:18);
x_offset = 0;
t_stance_stored = [];
p_swing_stored = [];
q_stance_stored = [];
dq_stance_stored = [];
u_stance_stored = [];
y_stance_stored = [];
s_stance_stored = [];
theta_stored = [];
dp_swing_stored = [];
dp_swing_stored = [];
F_stance_stored = [];
for step = 1:20
    
    [Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(X,M);
    [t_stance,q_stance,dq_stance,ddq_stance,u_stance,y_stance,dy_stance,F_stance,s_stance,ds_stance,p_swing,dp_swing,theta] = solve_stance_ODE(Xs_plus,a_matrix,theta_plus,theta_minus,AT,RT,RF);
    
    % store variables
    if (step == 1)
        t_stance_stored = [t_stance_stored;t_stance];
    else
        t_stance_stored = [t_stance_stored;t_stance + t_stance_stored(end)];
    end
    q_stance_stored = [q_stance_stored,q_stance];
    dq_stance_stored = [dq_stance_stored,dq_stance];
    u_stance_stored = [u_stance_stored, u_stance];
    y_stance_stored = [y_stance_stored, y_stance];
    s_stance_stored = [s_stance_stored; s_stance];
    theta_stored = [theta_stored, theta];
    p_swing_stored = [p_swing_stored, p_swing];
    dp_swing_stored = [dp_swing_stored,dp_swing];
    F_stance_stored = [F_stance_stored,F_stance];
    
    %plot 1 step
    for k = 1:length(t_stance)
        joint_pos = joint_position(q_stance(:,k),robot_params);
        p1(:,k) = joint_pos(:,1);
        p1Knee(:,k) = joint_pos(:,2);
        pcmH(:,k) = joint_pos(:,3);
        pcmTop(:,k) = joint_pos(:,4);
        p2Knee(:,k) = joint_pos(:,5);
        p2(:,k) = joint_pos(:,6);
        
        
        x1 = [p1(1,k) + x_offset; p1Knee(1,k) + x_offset];
        y1 = [p1(2,k) ; p1Knee(2,k)];
        
        x2 = [p1Knee(1,k) + x_offset; pcmH(1,k) + x_offset];
        y2 = [p1Knee(2,k); pcmH(2,k)];
        
        x3 = [pcmTop(1,k) + x_offset; pcmH(1,k) + x_offset];
        y3 = [pcmTop(2,k); pcmH(2,k)];
        
        x4 = [p2Knee(1,k) + x_offset; pcmH(1,k) + x_offset];
        y4 = [p2Knee(2,k); pcmH(2,k)];
        
        x5 = [p2Knee(1,k) + x_offset; p2(1,k) + x_offset];
        y5 = [p2Knee(2,k); p2(2,k)];
        
        clf;
        hold on
        axis equal
        grid on
%         xlim([-1.5 ,1.5])
        ylim([0 1.5])
        line(x1,y1,'LineWidth',3,'Color','b');
        line(x2,y2,'LineWidth',3,'Color','g');
        line(x3,y3,'LineWidth',3,'Color','r');
        line(x4,y4,'LineWidth',3,'Color','c');
        line(x5,y5,'LineWidth',3,'Color','m');
        
%         scatter(p1Knee(1,k),p1Knee(2,k),100,'filled','MarkerFaceColor','r');
%         scatter(p2Knee(1,k),p2Knee(2,k),100,'filled','MarkerFaceColor','r');
%         scatter(pcmH(1,k),pcmH(2,k),100,'filled','MarkerFaceColor','g');
%         line(groundx,groundy,'LineWidth',5,'Color','k');
%         pause(0.1)
        drawnow limitrate
    end
    
    x_offset = x_offset + p2(1,end); %extract the new zero
%     p_swing_stored = [p_swing_stored, p2(:,end)];
    
    %extract the last q and dq
    q_stance_end = q_stance(:,end);
    dq_stance_end = dq_stance(:,end);
    X = [q_stance_end; dq_stance_end;a2;a3];
end
%% plot results
if (1)
figure('Name','Joint Angle vs Joint Velocity')
for k = 1:5
    subplot(5,1,k)
    plot(q_stance_stored(k,:) * 180/pi,dq_stance_stored(k,:) * 180/pi)
    ylabel('Joint velocities(rad)')
    xlabel('Joint angles (rad/s)')
    grid on
    switch k
        case 1
            title('q1 angle vs velocity')
        case 2
            title('q31 angle vs velocity')
        case 3
            title('q32 angle vs velocity')    
        case 4
            title('q41 angle vs velocity')    
        case 5
            title('q42 angle vs velocity')  
    end
end

figure('Name','CoM Velocity')
subplot(2,1,1)
plot(t_stance_stored,dp_swing_stored(1,:))
grid on
legend('Horizontal COM velocity')
ylabel('Robot Velocity (m/s)')
xlabel('Time (s)')
subplot(2,1,2)
plot(t_stance_stored,dp_swing_stored(2,:))
grid on
legend('Vertical COM velocity')
ylabel('Robot Velocity (m/s)')
xlabel('Time (s)')

% figure('Name','Phasing variable')
% plot(t_stance_stored,theta_stored)
% grid on
% ylabel('Phasing variable')
% xlabel('Time (s)')

figure('Name','Joint angles over steps')
subplot(3,1,1)
plot(t_stance_stored,q_stance_stored(1,:) * 180/pi)
grid on
legend('q1')
ylabel('Joint Angle (deg)')
xlabel('Time (s)')
title('Torso angle')
subplot(3,1,2)
plot(t_stance_stored,q_stance_stored(2:3,:) * 180/pi)
grid on
legend('q31','q32')
ylabel('Joint Angle (deg)')
xlabel('Time (s)')
title('Hip angles')
subplot(3,1,3)
plot(t_stance_stored,q_stance_stored(4:5,:) * 180/pi)
grid on
legend('q41','q42')
ylabel('Joint Angle (deg)')
xlabel('Time (s)')
title('Knee angles')

figure('Name','Joint velocities over steps')
subplot(3,1,1)
plot(t_stance_stored,dq_stance_stored(1,:) * 180/pi)
grid on
legend('dq1')
ylabel('Joint Angle (deg/s)')
xlabel('Time (s)')
title('Torso velocity')
subplot(3,1,2)
plot(t_stance_stored,dq_stance_stored(2:3,:) * 180/pi)
grid on
legend('q31','q32')
ylabel('Joint Angle (deg/s)')
xlabel('Time (s)')
title('Hip velocities')
subplot(3,1,3)
plot(t_stance_stored,dq_stance_stored(4:5,:) * 180/pi)
grid on
legend('q41','q42')
ylabel('Joint Angle (deg/s)')
xlabel('Time (s)')
title('Knee velocities')

figure
plot(t_stance_stored,F_stance_stored)
grid on
ylabel('Stance Leg ground reaction force (N)')
xlabel('Time (s)')
legend('Horizonal force','Vertical Force')

% figure('Name','Joint velocity over steps')
% plot(t_stance_stored,dq_stance_stored)
% grid on
% legend('dq1','dq31','dq32','dq41','dq42')
% ylabel('Joint Angle (rad/s)')
% xlabel('Time (s)')


figure('Name','Swing Leg Position')
plot(t_stance_stored,p_swing_stored)
grid on
legend('Swing leg x pos','Swing leg y pos')

% figure('Name','output')
% plot(t_stance_stored,y_stance_stored)
% legend('Output')
% grid on

figure('Name','Control input')
plot(t_stance_stored,u_stance_stored)
grid on
ylabel('Control input (N/m)')
xlabel('Time (s)')
legend('Hip 1','Hip 2','Knee 1','Knee 2')

figure('Name','Scaled phasing variable')
plot(t_stance_stored,s_stance_stored)
grid on
ylabel('Sacled phasing variable')
xlabel('Time (s)')
end
