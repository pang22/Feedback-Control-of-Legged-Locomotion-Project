function [ddqs,F] = stance_phase_dynamics(qs,dqs,u,leg)

% This function generates the acceleration and GRF during the stance
% phases.

% Inputs:
%
% qs:  9-dim position
% dqs: 9-dim velocity
% u:   6-dim control inputs
% leg: scalar quantity (0 for the right stance phase and 1 for the left stance phase)

% Outputs
%
% ddqs: 9-dim acceleration
% F:    3-dim GRF
%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote)
%link lengths
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
%--------------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
% Modified code
[D,H,B,Cdq,G] = stance_phase_dynamic_terms(qs,dqs,leg);

%from L4
ddqs = -inv(D)*(Cdq+G) + inv(D)*B*u;
ddqe = [ddqs;0;0];

% Extend the q and dq
p0 = [0;0];
qe  = [qs;p0];
dqe = [dqs;[0;0]];

De = extended_inertia_Matrix(qe,robot_params);
Cedq = extended_coriolis_centrifugal_terms(qe,dqe,robot_params);
Ge = extended_gravity_terms(qe,robot_params);
Be = extended_input_matrix(qe,robot_params);
Je = extended_swing_Jacobian(qe,robot_params);

%Compute GRF (from L17) 
ddqe_F = inv([De,-transpose(Je);Je, zeros(2,2)]) * [Be * u - Cedq - Ge; zeros(2,1)];
F = ddqe_F(8:9);

% RHS = De * ddqe + Cedq + Ge;
% F = Je*(RHS - Be * u);
% from L4

%--------------------------------------------------------------------------

% Lift map
% if leg==0 % right stance
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Right(qs);
%     [vcm J_cm dJ_cm v0 J0 dJ0 v0T vHL vHR] = Cfcn_Robot_VelAccel_Right(qs,dqs);
% else % left stance
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Left(qs);
%     [vcm J_cm dJ_cm v0 J0 dJ0 v0T vHL vHR] = Cfcn_Robot_VelAccel_Left(qs,dqs);
% end % end of if
% 
% % Extended coordinates
% % q  = [p0; qs];
% % dq = [J0; eye(9,9)]*dqs;
% 
% % Flight dynamics
% [D,H,B] = flight_phase_dynamic_terms(q,dq);
% [v1R v1L J1R J1L dJ1R dJ1L] =  Cfcn_Robot_VelAccel_LegEnds_Hip(q,dq);
% 
% % Leg Jacoian matrices
% if leg==0 % right stance
%     J  = J1R;
%     dJ = dJ1R;
% else % left stance
%     J  = J1L;
%     dJ = dJ1L;
% end % end of if
% 
% if 1
%     % Constrained dyanmics
%     A   = [D -J'; J zeros(3,3)];
%     RHS = [B*u-H; -dJ*dq];
%     X    = A\RHS;
% else % planar model
%     C = zeros(5,12);
%     C(1,1)  = 1;
%     C(2,4)  = 1;
%     C(3,5)  = 1;
%     C(4,9)  = 1;
%     C(5,12) = 1;
%     J_temp  = [J; C];
%     J       = J_temp;
%     dJ_temp = [dJ; zeros(5,12)];
%     dJ      = dJ_temp;
%     A   = [D -J'; J zeros(8,8)];
%     RHS = [B*u-H; -dJ*dq];
%     X    = A\RHS;
% end
% 
% % Projection to find acceleration
% ddqs = X(4:12);
% 
% % GRF
% F    = X(13:15);

end

