function [D,H,B,Cdq,G] = stance_phase_dynamic_terms(qs,dqs,leg)

% This function generates the dyanmic terms during the stance
% phases.

% Inputs:
%
% qs:   9-dim position
% dqs:  9-dim velocity
% leg: scalar quantity (0 for the right stance phase and 1 for the left stance phase)

% Outputs
%
% Ds: 9x9 mass-inertia matrix
% Hs: 9-dim Coriolis and gravity terms vector
% Bs: 9x6 input matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote)
%link lengths
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
%--------------------------------------------------------------------------
% Modified code
D = inertia_Matrix(qs,robot_params);
B = input_matrix(qs,robot_params);
G = gravity_terms(qs,robot_params);
Cdq = Coriolis_centrifugal_terms(qs,dqs,robot_params);
H = Cdq + G; %From L13
%--------------------------------------------------------------------------

% % Lift map
% if leg==0 % right stance
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Right(qs);
%     [vcm J_cm dJ_cm v0 J0 dJ0 v0T vHL vHR] = Cfcn_Robot_VelAccel_Right(qs,dqs);
% else % left stance
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Left(qs);
%     [vcm J_cm dJ_cm v0 J0 dJ0 v0T vHL vHR] = Cfcn_Robot_VelAccel_Left(qs,dqs);
% end % end of if
% 
% % Extended coordinates
% q  = [p0; qs];
% dq = [J0; eye(9,9)]*dqs;
% 
% % Flight dynamics
% [D,H,B] = flight_phase_dynamic_terms(q,dq);
% [v1R v1L J1R J1L dJ1R dJ1L] =  Cfcn_Robot_VelAccel_LegEnds_Hip(q,dq);
% 
% % Leg Jacoian matrices
% if leg==0 % right stance
%     J  = J1R;
%     dJ = dJ1R;
% else % left stance
%     J  = J1L;
%     dJ = dJ1L;
% end % end of if
% 
% % Projection matrix
% proj = (eye(12,12) - J'*(((J/D)*J')\J)/D);
% 
% % Consterained H and B
% H_const = proj * H + J'*(((J/D)*J')\dJ)*dq;
% 
% % Constrained B
% B_const = proj * B;
% 
% % Projection to reduced coordinates
% Ds = [J0' eye(9,9)] * D * [J0; eye(9,9)];
% Hs = [J0' eye(9,9)] * (D * [dJ0*dqs; zeros(9,1)] + H_const);
% %Bs = [J0' eye(11,11)] * B_const;
% Bs =  B(4:12,:); % For numerical purposes

end

