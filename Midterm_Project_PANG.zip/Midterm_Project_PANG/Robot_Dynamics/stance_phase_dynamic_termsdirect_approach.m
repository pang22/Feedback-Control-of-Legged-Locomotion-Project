function [D,H,B] = stance_phase_dynamic_termsdirect_approach(q,dq,leg)

% This function generates the dyanmic terms during the stance phase.

% Inputs:
%
% q:   9-dim position
% dq:  9-dim velocity
% leg: scalar quantity (0 for the right stance phase and 1 for the left stance phase)

% Outputs
%
% D: 9x9 mass-inertia matrix
% H: 9-dim Coriolis and gravity terms vector
% B: 9x6 input matrix

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if leg==0 % right stance phase
    % Mass inertia
    D    = Cfcn_Robot_Mass_Inertia_Right_Parametric(q,dq);
    % Coriolis
    CdqT = Cfcn_RobotT_Coriolis_Centrifugal_Terms_Right_Parametric(q,dq);
    CdqR = Cfcn_RobotR_Coriolis_Centrifugal_Terms_Right_Parametric(q,dq);
    CdqL = Cfcn_RobotL_Coriolis_Centrifugal_Terms_Right_Parametric(q,dq);
    Cdq  = CdqT + CdqR + CdqL;
    % Gravity
    G    = Cfcn_Robot_Gravity_Terms_Right_Parametric(q,dq);
    % Coriolis and gravity
    H    = Cdq + G;
    % Input matrix
    B    = Cfcn_Robot_Input_Matrix_Right_Parametric(q,dq);
else % left stance phase
    % Mass inertia
    D    = Cfcn_Robot_Mass_Inertia_Left_Parametric(q,dq);
    % Coriolis
    CdqT = Cfcn_RobotT_Coriolis_Centrifugal_Terms_Left_Parametric(q,dq);
    CdqR = Cfcn_RobotR_Coriolis_Centrifugal_Terms_Left_Parametric(q,dq);
    CdqL = Cfcn_RobotL_Coriolis_Centrifugal_Terms_Left_Parametric(q,dq);
    Cdq  = CdqT + CdqR + CdqL;
    % Gravity
    G    = Cfcn_Robot_Gravity_Terms_Left_Parametric(q,dq);
    % Coriolis and gravity
    H    = Cdq + G;
    % Input matrix
    B    = Cfcn_Robot_Input_Matrix_Left_Parametric(q,dq);
end % end of if

end



