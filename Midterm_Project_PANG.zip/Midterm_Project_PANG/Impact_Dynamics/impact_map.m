function [qs_plus,dqs_plus,F_imp,dz_plus] = impact_map(qs_minus,dqs_minus,leg)

% This function returns the position and velocity just after the impact.
%
% Inputs:
%
% qs_minus:  9-dim position just before the impact
% dqs_minus: 9-dim velocity just before the impact
% leg:       stance phase indicator (0 if the previous stance phase was right and
% 1 if the previous stance phase was left)
%
% Outputs:
%
% qs_plus:  9-dim position just after the impact
% dqs_plus: 9-dim velocity just after the impact
% F_imp:    4-dim Lagrange multipliers at the impact model. The first three
% rows correspond to the impulsive force, whereas the last row is the
% impulsive torque, i.e., F_imp = [Fx Fy Fz Mz]'.

% For more details see Eq. (6) of

% K. Akbari Hamed and J. W. Grizzle, �Event-based stabilization of periodic
% orbits for underactuated 3D bipedal robots with left-right symmetry,�
% IEEE Transactions on Robotics, vol. 30, issue 2, pp. 365-381, April 2014
% http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=6663683

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Extended coordiantes
% qe_minus  = [qs_minus;  zeros(3,1)];
% dqe_minus = [dqs_minus; zeros(3,1)];

%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote)
%link lengths
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Modified code
qe_minus  = [qs_minus;  zeros(2,1)];
dqe_minus = [dqs_minus; zeros(2,1)];
%--------------------------------------------------------------------------

% Impact model
if leg==0 % right to left switching (impcat on the left leg)
%     [D,E]= Cfcn_Robot_ImpactModel_StanceRight_Parametric(qe_minus); 
    
    %--------------------------------------------------------------------------
    % Modified code
    D = extended_inertia_Matrix(qe_minus,robot_params);
    E = extended_swing_Jacobian(qe_minus,robot_params);
    %--------------------------------------------------------------------------
    
else % left to right switching (impact on the right leg)
%     [D,E]= Cfcn_Robot_ImpactModel_StanceLeft_Parametric(qe_minus); %Do I
%     modified this?
end % end of if

% A   = [D -E'; E zeros(4,4)];
% RHS = [D*dqe_minus; zeros(4,1)];
% X   = A\RHS; %same of inv(A)

%--------------------------------------------------------------------------
% Modified code (From L5)
A   = [D -E'; E zeros(2,2)];
RHS = [D*dqe_minus; zeros(2,1)];
X   = A\RHS; %same of inv(A)
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Deleted
% if 1
%     % do nothing
% else % plannar impact
%     X(1) = 0; X(2)= 0; X(6) = 0; X(9) = 0; %DO I KEEP THIS?
% end
%--------------------------------------------------------------------------

% dqe_plus = X(1:12);
% F_imp    = X(13:end); % F is 4-dim.

%--------------------------------------------------------------------------
% Modified code (from L5
dqe_plus = X(1:7);
F_imp    = X(8:end); % F is 2-dim
%--------------------------------------------------------------------------
qs_plus  = qs_minus; % continuity of position

% if 1
%     % do nothing
% else % plannar impact
%     qs_plus(1) = 0; qs_plus(2) = 0; qs_plus(6) = 0; qs_plus(9) = 0; %DO I KEEP THIS?
% end

% dqs_plus = dqe_plus(1:9);
% dz_plus  = dqe_plus(12);

%--------------------------------------------------------------------------
% Modified code
dqs_plus = dqe_plus(1:5);
dz_plus  = dqe_plus(7);
%--------------------------------------------------------------------------
end

