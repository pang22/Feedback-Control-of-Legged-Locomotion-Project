/*
 * bezierd_types.h
 *
 * Code generation for function 'bezierd'
 *
 */

#ifndef __BEZIERD_TYPES_H__
#define __BEZIERD_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (bezierd_types.h) */
