/*
 * bezierd_data.c
 *
 * Code generation for function 'bezierd_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "bezierd.h"
#include "bezierd_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;

/* End of code generation (bezierd_data.c) */
