/*
 * beziera_data.c
 *
 * Code generation for function 'beziera_data'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "beziera.h"
#include "beziera_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;

/* End of code generation (beziera_data.c) */
