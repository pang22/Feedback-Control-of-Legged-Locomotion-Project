/*
 * beziera_initialize.c
 *
 * Code generation for function 'beziera_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "beziera.h"
#include "beziera_initialize.h"
#include "beziera_data.h"

/* Function Definitions */
void beziera_initialize(emlrtContext *aContext)
{
  emlrtStack st = { NULL, NULL, NULL };

  emlrtBreakCheckR2012bFlagVar = emlrtGetBreakCheckFlagAddressR2012b();
  emlrtCreateRootTLS(&emlrtRootTLSGlobal, aContext, NULL, 1);
  st.tls = emlrtRootTLSGlobal;
  emlrtClearAllocCountR2012b(&st, false, 0U, 0);
  emlrtEnterRtStackR2012b(&st);
  emlrtFirstTimeR2012b(emlrtRootTLSGlobal);
}

/* End of code generation (beziera_initialize.c) */
