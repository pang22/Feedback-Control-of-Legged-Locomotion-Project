/*
 * beziera_api.c
 *
 * Code generation for function 'beziera_api'
 *
 * C source code generated on: Thu Sep 25 15:45:50 2014
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "beziera.h"
#include "beziera_api.h"

/* Type Definitions */
#ifndef typedef_ResolvedFunctionInfo
#define typedef_ResolvedFunctionInfo

typedef struct {
  const char * context;
  const char * name;
  const char * dominantType;
  const char * resolved;
  uint32_T fileTimeLo;
  uint32_T fileTimeHi;
  uint32_T mFileTimeLo;
  uint32_T mFileTimeHi;
} ResolvedFunctionInfo;

#endif                                 /*typedef_ResolvedFunctionInfo*/

/* Function Declarations */
static real_T (*b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId))[36];
static real_T c_emlrt_marshallIn(const mxArray *s, const char_T *identifier);
static real_T d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId);
static real_T (*e_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId))[36];
static real_T (*emlrt_marshallIn(const mxArray *afra, const char_T *identifier))
  [36];
static const mxArray *emlrt_marshallOut(real_T u[6]);
static real_T f_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId);

/* Function Definitions */
static real_T (*b_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId))[36]
{
  real_T (*y)[36];
  y = e_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}
  static real_T c_emlrt_marshallIn(const mxArray *s, const char_T *identifier)
{
  real_T y;
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  y = d_emlrt_marshallIn(emlrtAlias(s), &thisId);
  emlrtDestroyArray(&s);
  return y;
}

static real_T d_emlrt_marshallIn(const mxArray *u, const emlrtMsgIdentifier
  *parentId)
{
  real_T y;
  y = f_emlrt_marshallIn(emlrtAlias(u), parentId);
  emlrtDestroyArray(&u);
  return y;
}

static real_T (*e_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier *
  msgId))[36]
{
  real_T (*ret)[36];
  int32_T iv4[2];
  int32_T i;
  for (i = 0; i < 2; i++) {
    iv4[i] = 6;
  }

  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", FALSE, 2U,
    iv4);
  ret = (real_T (*)[36])mxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}
  static real_T (*emlrt_marshallIn(const mxArray *afra, const char_T *identifier))
  [36]
{
  real_T (*y)[36];
  emlrtMsgIdentifier thisId;
  thisId.fIdentifier = identifier;
  thisId.fParent = NULL;
  y = b_emlrt_marshallIn(emlrtAlias(afra), &thisId);
  emlrtDestroyArray(&afra);
  return y;
}

static const mxArray *emlrt_marshallOut(real_T u[6])
{
  const mxArray *y;
  static const int32_T iv2[1] = { 0 };

  const mxArray *m1;
  static const int32_T iv3[1] = { 6 };

  y = NULL;
  m1 = mxCreateNumericArray(1, (int32_T *)&iv2, mxDOUBLE_CLASS, mxREAL);
  mxSetData((mxArray *)m1, (void *)u);
  mxSetDimensions((mxArray *)m1, iv3, 1);
  emlrtAssign(&y, m1);
  return y;
}

static real_T f_emlrt_marshallIn(const mxArray *src, const emlrtMsgIdentifier
  *msgId)
{
  real_T ret;
  emlrtCheckBuiltInR2012b(emlrtRootTLSGlobal, msgId, src, "double", FALSE, 0U, 0);
  ret = *(real_T *)mxGetData(src);
  emlrtDestroyArray(&src);
  return ret;
}

void beziera_api(const mxArray * const prhs[2], const mxArray *plhs[1])
{
  real_T (*value)[6];
  real_T (*afra)[36];
  real_T s;
  value = (real_T (*)[6])mxMalloc(sizeof(real_T [6]));

  /* Marshall function inputs */
  afra = emlrt_marshallIn(emlrtAlias(prhs[0]), "afra");
  s = c_emlrt_marshallIn(emlrtAliasP(prhs[1]), "s");

  /* Invoke the target function */
  beziera(*afra, s, *value);

  /* Marshall function outputs */
  plhs[0] = emlrt_marshallOut(*value);
}

const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  ResolvedFunctionInfo info[1];
  ResolvedFunctionInfo (*b_info)[1];
  ResolvedFunctionInfo u[1];
  const mxArray *y;
  int32_T iv1[1];
  ResolvedFunctionInfo *r0;
  const char * b_u;
  const mxArray *b_y;
  const mxArray *m0;
  const mxArray *c_y;
  const mxArray *d_y;
  const mxArray *e_y;
  uint32_T c_u;
  const mxArray *f_y;
  const mxArray *g_y;
  const mxArray *h_y;
  const mxArray *i_y;
  nameCaptureInfo = NULL;
  b_info = (ResolvedFunctionInfo (*)[1])info;
  (*b_info)[0].context = "[E]Z:/ATRIAS_Running/Bezier_Polynomials/beziera.m";
  (*b_info)[0].name = "mtimes";
  (*b_info)[0].dominantType = "double";
  (*b_info)[0].resolved =
    "[ILXE]$matlabroot$/toolbox/eml/lib/matlab/ops/mtimes.m";
  (*b_info)[0].fileTimeLo = 1289552092U;
  (*b_info)[0].fileTimeHi = 0U;
  (*b_info)[0].mFileTimeLo = 0U;
  (*b_info)[0].mFileTimeHi = 0U;
  u[0] = info[0];
  y = NULL;
  iv1[0] = 1;
  emlrtAssign(&y, mxCreateStructArray(1, iv1, 0, NULL));
  r0 = &u[0];
  b_u = r0->context;
  b_y = NULL;
  m0 = mxCreateString(b_u);
  emlrtAssign(&b_y, m0);
  emlrtAddField(y, b_y, "context", 0);
  b_u = r0->name;
  c_y = NULL;
  m0 = mxCreateString(b_u);
  emlrtAssign(&c_y, m0);
  emlrtAddField(y, c_y, "name", 0);
  b_u = r0->dominantType;
  d_y = NULL;
  m0 = mxCreateString(b_u);
  emlrtAssign(&d_y, m0);
  emlrtAddField(y, d_y, "dominantType", 0);
  b_u = r0->resolved;
  e_y = NULL;
  m0 = mxCreateString(b_u);
  emlrtAssign(&e_y, m0);
  emlrtAddField(y, e_y, "resolved", 0);
  c_u = r0->fileTimeLo;
  f_y = NULL;
  m0 = mxCreateNumericMatrix(1, 1, mxUINT32_CLASS, mxREAL);
  *(uint32_T *)mxGetData(m0) = c_u;
  emlrtAssign(&f_y, m0);
  emlrtAddField(y, f_y, "fileTimeLo", 0);
  c_u = r0->fileTimeHi;
  g_y = NULL;
  m0 = mxCreateNumericMatrix(1, 1, mxUINT32_CLASS, mxREAL);
  *(uint32_T *)mxGetData(m0) = c_u;
  emlrtAssign(&g_y, m0);
  emlrtAddField(y, g_y, "fileTimeHi", 0);
  c_u = r0->mFileTimeLo;
  h_y = NULL;
  m0 = mxCreateNumericMatrix(1, 1, mxUINT32_CLASS, mxREAL);
  *(uint32_T *)mxGetData(m0) = c_u;
  emlrtAssign(&h_y, m0);
  emlrtAddField(y, h_y, "mFileTimeLo", 0);
  c_u = r0->mFileTimeHi;
  i_y = NULL;
  m0 = mxCreateNumericMatrix(1, 1, mxUINT32_CLASS, mxREAL);
  *(uint32_T *)mxGetData(m0) = c_u;
  emlrtAssign(&i_y, m0);
  emlrtAddField(y, i_y, "mFileTimeHi", 0);
  emlrtAssign(&nameCaptureInfo, y);
  emlrtNameCapturePostProcessR2012a(emlrtAlias(nameCaptureInfo));
  return nameCaptureInfo;
}

/* End of code generation (beziera_api.c) */
