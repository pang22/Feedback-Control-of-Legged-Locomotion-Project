/*
 * beziera_terminate.h
 *
 * Code generation for function 'beziera_terminate'
 *
 */

#ifndef __BEZIERA_TERMINATE_H__
#define __BEZIERA_TERMINATE_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "beziera_types.h"

/* Function Declarations */
extern void beziera_atexit(void);
extern void beziera_terminate(void);

#endif

/* End of code generation (beziera_terminate.h) */
