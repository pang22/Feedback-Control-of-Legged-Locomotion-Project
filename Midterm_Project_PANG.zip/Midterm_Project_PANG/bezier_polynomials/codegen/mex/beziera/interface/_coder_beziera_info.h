/*
 * _coder_beziera_info.h
 *
 * Code generation for function 'beziera'
 *
 */

#ifndef ___CODER_BEZIERA_INFO_H__
#define ___CODER_BEZIERA_INFO_H__
/* Include files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

#endif
/* End of code generation (_coder_beziera_info.h) */
