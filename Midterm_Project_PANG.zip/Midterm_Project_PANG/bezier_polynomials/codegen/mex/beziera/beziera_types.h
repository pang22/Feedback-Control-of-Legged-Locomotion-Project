/*
 * beziera_types.h
 *
 * Code generation for function 'beziera'
 *
 */

#ifndef __BEZIERA_TYPES_H__
#define __BEZIERA_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (beziera_types.h) */
