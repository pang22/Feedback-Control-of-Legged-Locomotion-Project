/*
 * bezier_types.h
 *
 * Code generation for function 'bezier'
 *
 */

#ifndef __BEZIER_TYPES_H__
#define __BEZIER_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (bezier_types.h) */
