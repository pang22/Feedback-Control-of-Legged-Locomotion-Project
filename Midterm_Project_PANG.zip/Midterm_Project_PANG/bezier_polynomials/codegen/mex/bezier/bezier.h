/*
 * bezier.h
 *
 * Code generation for function 'bezier'
 *
 */

#ifndef __BEZIER_H__
#define __BEZIER_H__

/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "bezier_types.h"

/* Function Declarations */
extern void bezier(const emlrtStack *sp, const real_T afra[84], real_T s, real_T
                   value[4]);

#endif

/* End of code generation (bezier.h) */
