function [alpha_Rstance,dalpha_Rstance,beta_Rstance,gamma_Rstance,dgamma_Rstance,X_Rstance,eta_Rstance,U_Rstance,time_Rstance,s_Rstance] = Extract_Periodic_Orbit_Main(time,leg,s_variable,ds_variable,Q,dQ,YAW_HR,YAW_HL,ROLL_HR,ROLL_HL,dYAW_HR,dYAW_HL,dROLL_HR,dROLL_HL,U,extract_beginning,theta_s_plus,theta_s_minus,bez_order)

cd Extract_Orbit

% Find the leg change index
index_leg = find(diff(leg))+1;
index_leg = [1 index_leg];

% Where to extract the orbit? (beginning or end)
if extract_beginning==1
    if leg(index_leg(1))==0
        I_initial = index_leg(1);
        I_final   = index_leg(2)-1;
    else
        I_initial = index_leg(2);
        I_final   = index_leg(3)-1;
    end % end of if
else
    if leg(index_leg(end-1))==0
        I_initial = index_leg(end-1);
        I_final   = index_leg(end)-1;
    else
        I_initial = index_leg(end);
        I_final   = length(leg);
    end % end of if
end % end oif if

% Sample Data
% Right stance phase
Q_Rstance     = Q(:,I_initial:I_final);
dQ_Rstance    = dQ(:,I_initial:I_final);
eta_Rstance   = [YAW_HR(I_initial:I_final); YAW_HL(I_initial:I_final); ROLL_HR(I_initial:I_final); ROLL_HL(I_initial:I_final)];
deta_Rstance  = [dYAW_HR(I_initial:I_final); dYAW_HL(I_initial:I_final); dROLL_HR(I_initial:I_final); dROLL_HL(I_initial:I_final)];
U_Rstance     = U(:,I_initial:I_final);
X_Rstance     = [Q_Rstance; dQ_Rstance];
time_Rstance  = time(I_initial:I_final) - time(I_initial);
s_Rstance     = s_variable(I_initial:I_final);
s_Rstance(1)  = 0; s_Rstance(end) = 1;
ds_Rstance    = ds_variable(I_initial:I_final);
dQ_Rstance_ds = divide_matrix_by_vector(dQ_Rstance,ds_Rstance);
deta_Rstance_ds = divide_matrix_by_vector(deta_Rstance,ds_Rstance);

% Regress Data
free_vector      = ones(1,bez_order+1);
free_vector(1)   = 0;
free_vector(end) = 0;
alpha_Rstance    = bezfit(s_Rstance, Q_Rstance, free_vector); 
dalpha_Rstance   = bezfit(s_Rstance, dQ_Rstance_ds, free_vector);
beta_Rstance     = bezfit(s_Rstance, U_Rstance, free_vector); 
gamma_Rstance    = bezfit(s_Rstance, eta_Rstance, free_vector); 
dgamma_Rstance   = bezfit(s_Rstance, deta_Rstance, free_vector); 

% Save data
fcn_name = 'periodic_orbit_data';
generate_regressed_data;

cd ..

end
