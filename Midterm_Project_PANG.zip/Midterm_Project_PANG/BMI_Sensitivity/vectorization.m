function [a] = vectorization(A)

[m,n] = size(A);
a = zeros(m*n,1);

counter = 1;
for k=1:n
    a(counter:counter+m-1) = A(:,k);
    counter = counter + m;
end % end of for

end

