function [value,isterminal,direction] = stance_phase_events(t,x,leg,theta_plus,theta_minus,alpha)

% This function calculates the evnt function for the stance phase
%
% Inputs:
% t: time
% x: 18-dim state variable during the stance phase
% leg: 0 for the right stance and 1 for the left stance
% theta_plus:  initial value of theta on the orbit
% theta_minus: final value of theta on the orbit
% alpha: coefficient matrix for the bezier polynomial
%
% Outputs:
% value: the event-function
% isterminal: stop condition
% direction: the time derivative sign
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote)
%link lengths
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
%--------------------------------------------------------------------------
% Position and velocity
% q  = x(1:9);
% dq = x(10:18);
%--------------------------------------------------------------------------
% Modified code
q  = x(1:5);
dq = x(6:10);
%--------------------------------------------------------------------------

% Swing leg end
% if leg==0 % right stance phase
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Right(q);
%     value = p1L(3);
%--------------------------------------------------------------------------
% Modified code
    fk_output = joint_position(q,robot_params);
%     fk_output = forward_kinematics(q,robot_params);
%     value = fk_output(2,1);
    value = fk_output(2,6); %swing leg end position
%--------------------------------------------------------------------------
% else % left stance phase
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Left(q);
%     value = p1R(3);
% end % end of if

[s,ds,ds_dq] = scaled_phasing_variable(x,leg,theta_plus,theta_minus);
if s>0.9
    % nothing
else
    value = 1;
end

% Stop conditions
isterminal(1) = 1;
direction(1)  = -1; % It is decreasing

end
