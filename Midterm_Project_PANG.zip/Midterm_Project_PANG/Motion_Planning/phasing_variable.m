function [theta,dtheta,dtheta_dq] = phasing_variable(x,leg)
%#codegen
% This function calculates the phasing variable.
%
% Inputs:
% x:   18-dim state variable during the stance phase
% leg: 0 for the right stance and 1 for the left stance
%
% Outputs:
% theta:     phasing variable
% dtheta:    time derivative of the phasing variable
% dtheta_dq: 1x9 jacobian matrix 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Position and velocity
% q  = x(1:9);
% dq = x(10:18);

%--------------------------------------------------------------------------
% Modified code
q  = x(1:5);
dq = x(6:10);
%--------------------------------------------------------------------------

% c1    = zeros(1,9);

%--------------------------------------------------------------------------
%Placeholder, NOT right probably
% c1    = zeros(1,5);
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
% Matrices (WHAT IS THIS?) 
% c1(3) = -1;
% c1(4) =  1/2;
% c1(5) = -1;
% c0    = 3*pi/2;
%--------------------------------------------------------------------------
% From Lecture 15 and Rabbit Relabelling from my one note
c0    = -pi/2; 
c1    = [-1 -1 0 0.5 0];
%-------------------------------------------------------------------------

% if leg==0 % right leg
%     nothing to do
% else % left leg
%     [Sqs,Sqf,Sxs,Sxf] = state_symmetry_matrices;
%     c1 = c1*Sqs;
% end % end of if


% c1 should be 1 by 5
theta     = c1*q+c0;
dtheta    = c1*dq;
dtheta_dq = c1;

end

