function [u,h,dh] = normal_controller(x,leg,theta_plus,theta_minus,alpha)

% This function calculates the normal controller.
%
% Inputs:
% x: 18-dim state variable during the stance phase
% leg: 0 for the right stance and 1 for the left stance
% theta_plus:  initial value of theta on the orbit
% theta_minus: final value of theta on the orbit
% alpha: coefficient matrix for the bezier polynomial
%
% Outputs:
% u: 6-dim continuous-time controller
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Position and velocity
% q  = x(1:9);
% dq = x(10:18);
%--------------------------------------------------------------------------
% Modified code
q  = x(1:5);
dq = x(6:10);
%--------------------------------------------------------------------------

% Output function
[h,dh,dh_dq,ddh_ddq] = normal_outputs(x,leg,theta_plus,theta_minus,alpha);

% Normal output function
[~,~,H0] = normal_controlled_variables(x,leg);

% Dynamnic terms
[D,H,B,~,~] = stance_phase_dynamic_terms(q,dq,leg);
  
% I/O controller
LgLfh    =  (dh_dq/D) * B; %From L15
%LgLfh    =  H0 * B;
Lf2h     = -(dh_dq/D) * H + ddh_ddq; %From L15
%Lf2h     = ddh_ddq; 

[KP,KD,epsilon] = Controller_Gains;
u = -LgLfh\Lf2h - LgLfh\(KD/epsilon * dh + KP/epsilon^2 * h); %From L15

end

