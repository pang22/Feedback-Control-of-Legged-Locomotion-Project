function [t,q,dq,ddq,u,y,dy,F,s,ds,p_swing,dp_swing,theta] = solve_stance_ODE(Xs_plus,a_matrix,theta_plus,theta_minus,AT,RT,RF)

% This function solves the ODE for the stance phase dynamics.

%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote)
%link lengths
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
%--------------------------------------------------------------------------
warning('off', 'MATLAB:ode113:IntegrationTolNotMet');

% Sslve ODE
t_span  = [0 1];
x0      = Xs_plus;
options = odeset('AbsTol',AT,'RelTol',RT,'Refine',RF,'MaxStep',0.01,'events',@stance_phase_events);
t       = [];
x       = [];
[t,x]   = ode113(@stance_closed_loop_dynamics,t_span,x0,options,0,theta_plus,theta_minus,a_matrix);
x_temp  = x;
x       = x_temp';

% q       = x(1:9,:);  % Position
% dq      = x(10:18,:); % Velocity
%--------------------------------------------------------------------------
% Modified code
q  = x(1:5,:);
dq = x(6:10,:);
%--------------------------------------------------------------------------

% Calculate u, y, dy, ddq, GRF, s, ds and p_swing
% [~,n]    = size(q);
% ddq      = zeros(9,n);
% u        = zeros(6,n);
% y        = zeros(6,n);
% dy       = zeros(6,n);
% F        = zeros(3,n);
% s        = 0*t;
% ds       = 0*t;
% p_swing  = zeros(3,n);
% dp_swing = zeros(3,n);
%--------------------------------------------------------------------------
% Modified code
[~,n]    = size(q);
ddq      = zeros(5,n);
u        = zeros(4,n);
y        = zeros(4,n);
dy       = zeros(4,n);
F        = zeros(2,n);
s        = 0*t;
ds       = 0*t;
p_swing  = zeros(2,n);
dp_swing = zeros(2,n);
%--------------------------------------------------------------------------
for k=1:n
    [u_temp,y_temp,dy_temp] = normal_controller(x(:,k),0,theta_plus,theta_minus,a_matrix);
    u(:,k)   = u_temp;
    y(:,k)   = y_temp;
    dy(:,k)  = dy_temp;
    [ddq_temp,F_temp] = stance_phase_dynamics(q(:,k),dq(:,k),u(:,k),0);
    ddq(:,k)  = ddq_temp;
    F(:,k)    = F_temp;
    [s_temp,ds_temp,~] = scaled_phasing_variable(x(:,k),0,theta_plus,theta_minus);
    s(k)      = s_temp;
    ds(k)     = ds_temp;
%     [pcm p0 p0T pHR p1R p2R p3R pHL p1L p2L p3L] = Cfcn_Robot_Primary_Points_Right(q(:,k));
%     [v1R v1L J1R J1L dJ1R dJ1L] = Cfcn_Robot_VelAccel_LegEnds_Right(q(:,k),dq(:,k));
%     p_swing(:,k)  = p1L;
    %--------------------------------------------------------------------------
    % Modified code 
    jos_pos = joint_position(q(:,k),robot_params);
    p_swing(:,k) = jos_pos(:,6);
    %--------------------------------------------------------------------------
    %--------------------------------------------------------------------------
    % Modified code 
    dp_swing_temp = robot_velocity(q(:,k),dq(:,k),robot_params); %Might need this
    dp_swing(:,k) = dp_swing_temp;
    %--------------------------------------------------------------------------
    
    %added code to print out phasing variable
    [theta_temp,~,~] = phasing_variable(x(:,k),0);
    theta(k) = theta_temp;
    
end % end of loop

end



