function [Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(p,M)

% This function extracts the optimization variables from the input vector
% p. Here p is a 6M dimesional vector, where M is the degree of the Bezier 
% polynomial.

% Inputs:
%
% p : optimization variables as a 6M dimensional vector
% M : degree of the Bezier polynomial
% 
% Outputs:
% 
% Xs_minus : state variables at the end of the right stance phase
% a_matrix : coefficient matrix for the Bezier polynomial during the right stance phase

%--------------------------------------------------------------------------

% Extract final state vector at the end of the right stance phase
% Xs_minus  = p(1:18);
% qs_minus  = Xs_minus(1:9);
% dqs_minus = Xs_minus(10:18);

%--------------------------------------------------------------------------
% Modified code
Xs_minus  = p(1:10);
qs_minus  = Xs_minus(1:5);
dqs_minus = Xs_minus(6:10);
%--------------------------------------------------------------------------

% Calculate initial condition at the beginning of the right stance phase
[qs_plus,dqs_plus,F_imp,dz_plus] = impact_map(qs_minus,dqs_minus,0); % obtain initial condition at the beginning of the left stance
Xs_plus = [qs_plus; dqs_plus]; % initial condition at the beginning of the left stance phase

R = state_symmetry_matrices;
% Xs_plus = Sxs * Xs_plus; % apply symmetry to get the initial condition at the beginning of the right stace phase

%--------------------------------------------------------------------------
%Relabeling
qs_plus = R * qs_plus;
dqs_plus = R * dqs_plus;
Xs_plus = [qs_plus; dqs_plus]; 
%--------------------------------------------------------------------------

% Get the initial and final phasing variables
[theta_plus,~,~]  = phasing_variable(Xs_plus,0);  % initial value for theta 
[theta_minus,~,~] = phasing_variable(Xs_minus,0); % final value for theta 

% Calculate scaled phasing variables and their time derivatives at the beginning
% and end of the right stance phase
[s_plus,ds_plus,~]   = scaled_phasing_variable(Xs_plus,0,theta_plus,theta_minus);
[s_minus,ds_minus,~] = scaled_phasing_variable(Xs_minus,0,theta_plus,theta_minus);

% Calculate the first and last two columns of the a matrix
[h0_plus,dh0_plus,~]   = normal_controlled_variables(Xs_plus,0);
[h0_minus,dh0_minus,~] = normal_controlled_variables(Xs_minus,0);

% Se L17
a0   = h0_plus;
aM   = h0_minus;
a1   = a0 + 1/(M * ds_plus)  * dh0_plus;
aM_1 = aM - 1/(M * ds_minus) * dh0_minus;

% Extract middle columns of a and b matrices
% a_vec    = p(19:end); % vectorization of middle columns of a
% a_middle = matricization(a_vec,6,M-3); %a_middle is 4 by 2
%--------------------------------------------------------------------------
% Modified code
a_vec    = p(11:end); % vectorization of middle columns of a
a_middle = matricization(a_vec,4,2); %a_middle is 4 by 2
%--------------------------------------------------------------------------
a_matrix = [a0 a1 a_middle aM_1 aM]; %a matrix is 4 by 6 from L15

end


