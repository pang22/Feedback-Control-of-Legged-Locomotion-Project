function [dx] = stance_closed_loop_dynamics(t,x,leg,theta_plus,theta_minus,alpha)

% This function calculates the derivative of the state vector for the stance phase.
%
% Inputs:
% t: time
% x: 18-dim state variable during the stance phase
% leg: 0 for the right stance and 1 for the left stance
% theta_plus:  initial value of theta on the orbit
% theta_minus: final value of theta on the orbit
% alpha: coefficient matrix for the bezier polynomial
%
% Outputs:
% dx: 18-dim time derivative of the state vector
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Position and velocity
% q  = x(1:9);
% dq = x(10:18);
%--------------------------------------------------------------------------
% Modified code
q  = x(1:5);
dq = x(6:10);
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
% Modified code
% Dynamic terms
[D,H,B,Cdq,G] = stance_phase_dynamic_terms(q,dq,leg);
%--------------------------------------------------------------------------

% Controller
[u,h,dh] = normal_controller(x,leg,theta_plus,theta_minus,alpha);

% Constraint matrix for planar motion
% C = zeros(4,9);
% C(1,1) = 1;
% C(2,2) = 1;
% C(3,6) = 1;
% C(4,9) = 1;
% lambda = zeros(4,1);

% if 0 % planar motion
%     lambda = -((((C/D)*C')\C)/D)*(B*u-H);
%     %lambda = -inv(C*inv(D)*C')*C*inv(D)*(B*u-H);
% end

% dx = f(x,u)
% dx = [dq; D\(B*u-H+C'*lambda)];

%--------------------------------------------------------------------------
% Modified code
% From L4
dx = [dq; -inv(D)*(Cdq+G)] + [zeros(5,1);inv(D)*B*u];
%--------------------------------------------------------------------------
end

