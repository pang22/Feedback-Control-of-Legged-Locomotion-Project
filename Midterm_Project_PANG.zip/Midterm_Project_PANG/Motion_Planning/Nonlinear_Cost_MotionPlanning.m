function [J] = Nonlinear_Cost_MotionPlanning(p,optim_option)

% This function returns the inequality and equality constraints for the
% motion planning algorithm.

% Inputs:
%
% p: decision variables of dimension 8*M-2, where M is the degree of the Bezier polynomial
% optim_option: options for the motion planning algorithm
%
% Outputs:
%
% Cineq: inequality constraints
% Ceq:   equality constraints
LT = 0.625; %Torso Length (m)
PTM = 0.4;%Torso CoM Location (m)
Lf = 0.4; %Fumur Lenngth (m)

PfM = 0.15;...%Femur CoM Location (m)
Lt = 0.4; %Tibias Length (m)
PtM = 0.15;%Tibias CoM Location (m)

MT = 20; %Torso mass (kg)
Mf = 6.8; %Femur mass (kg)
Mt = 3.2; %Tibias mass (kg)

IT = 2.22; %Torso inertia (m^2 * kg)
If = 1.08; %Femur inertia (m^2 * kg)
It = 0.93; %Tibias inertia (m^2 * kg)

g = 9.81; %Gravity Coefficent (m/s^2)

robot_params = [LT; PTM; Lf; PfM; Lt; PtM;...
                MT; Mf; Mt; IT; If; It; g];
%--------------------------------------------------------------------------

% Extract optimization parameters
M                 = optim_option.M;
AT                = optim_option.AT;
RT                = optim_option.RT;
RF                = optim_option.RF;
ds_min            = optim_option.ds_min;
q_min_stance      = optim_option.q_min_stance;
q_max_stance      = optim_option.q_max_stance;
dq_min_stance     = optim_option.dq_min_stance;
dq_max_stance     = optim_option.dq_max_stance;
u_max             = optim_option.u_max;
F_min_v           = optim_option.F_min_v;
F_min_v_impuslive = optim_option.F_min_v_impuslive;
mu_s              = optim_option.mu_s;
step_length_min   = optim_option.step_length_min;
ave_velocity_min  = optim_option.ave_velocity_min;
p_swing_h_min     = optim_option.p_swing_h_min;
t_s_min           = optim_option.t_s_min;

if 1
    %--------------------------------------------------------------------------
    
    % Extract decision variables
    [Xs_plus,Xs_minus,F_imp,a_matrix,theta_plus,theta_minus,dz_plus] = extract_optimization_variables(p,M);
    
    % Solve the stance ODE
    [t_stance,q_stance,dq_stance,ddq_stance,u_stance,y_stance,dy_stance,F_stance,s_stance,ds_stance,p_swing,dp_swing] = solve_stance_ODE(Xs_plus,a_matrix,theta_plus,theta_minus,AT,RT,RF);
    
    %--------------------------------------------------------------------------
    
    % Step length from L16
    step_length = abs(p_swing(1,end));

    %Sum the 4 inputs together
    sum = 0;
    for k = 1:length(t_stance)-1
%     for k = 1:m-1
        dt = t_stance(k+1) - t_stance(k);
        sum = sum + norm(u_stance(:,k))^2 * dt;
    end

%     J = sum / step_length; % use step length (L16)
     J = sum / t_stance(end); % use step time  (L17)
    
    
    
%--------------------------------------------------------------------------
% Deleted Code
%     if 0
%         % Calculate cost
%         sum_stance = 0;
%         for k=1:length(t_stance)-1
%             sum_stance = sum_stance + norm(u_stance(:,k),2)^2 * (t_stance(k+1) - t_stance(k));
%         end % end of for
%         J = sum_stance; %/step_length;
%     else % CMT
%         % Calculate cost
%         B   = Cfcn_Robot_Input_Matrix_Right_Parametric(zeros(9,1),zeros(9,1));
%         dqa = B' * dq_stance;
%         [m,~] = size(dqa);
%         sum_stance = 0;
%         for k=1:length(t_stance)-1
%             for j=1:m
%                 sum_stance = sum_stance + max(u_stance(j,k)*dqa(j,k),0) * (t_stance(k+1) - t_stance(k));
%             end % end of for
%         end % end of for
%         [~,~,~,~,~,m1,m2,m3,mT,~,~,~,~,~,~,~,~,~,~,~,~] = Human_Body_Parameters;
%         m_tot = 2*(m1 + m2 + m3) + mT;
%         g = 9.81;
%         J = sum_stance/(m_tot*g*step_length);
%         
%         %step_length   = p_swing(2,end);
%         %ave_velocity  = step_length/t_stance(end);
%         %J = -ave_velocity;
%     end
else
    J = 1;
end

end


