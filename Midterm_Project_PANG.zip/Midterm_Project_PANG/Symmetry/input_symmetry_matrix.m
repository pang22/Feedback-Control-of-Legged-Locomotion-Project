function [Su] = input_symmetry_matrix
%#codegen
% This function returns the input symmetry matrix.
%
% Output
%
% Su: 6x6 input symmetry matrix
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input symmetry matrix
Su = zeros(6,6);
Su(1:3,4:6) = eye(3,3);
Su(4:6,1:3) = eye(3,3);

end


