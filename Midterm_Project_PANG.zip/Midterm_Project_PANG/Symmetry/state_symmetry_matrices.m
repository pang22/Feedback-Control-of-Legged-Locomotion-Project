% function [Sqs,Sqf,Sxs,Sxf] = state_symmetry_matrices
%--------------------------------------------------------------------------
% Added code
function [R] = state_symmetry_matrices
%#codegen
% This function returns the symmetry matrices.
%
% Outputs
%
% Sqs: 9x9 position symmetry matrix for the stance phase
% Sqf: 12x12 position symmetry matrix for the flight phase
% Sxs: 18x18 tate symmetry matrix for the stance phase
% Sxf: 24x24 state symmetry matrix for the flight phase
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% % Stance position symmetry
% Sqs      = zeros(9,9);
% Sqs(1,1) = -1;
% Sqs(2,2) = -1;
% Sqs(3,3) = 1;
% Sqs(4,7) = 1; Sqs(7,4) = 1;
% Sqs(5,8) = 1; Sqs(8,5) = 1;
% Sqs(6,9) = 1; Sqs(9,6) = 1;
% 
% % Flight position symmetry
% Sxyz      = eye(3,3);
% Sxyz(1,1) = -1;
% Sqf       = [Sxyz zeros(3,9); zeros(9,3) Sqs];
% 
% % Stance state symmetry 
% Sxs = [Sqs 0*Sqs; 0*Sqs Sqs];
% 
% % Flight state symmetry
% Sxf = [Sqf 0*Sqf; 0*Sqf Sqf];

%--------------------------------------------------------------------------
% Added code (See Bo Pang's Onenote Rabbit Relabelling)
R = [1 0 0 0 0;...
     0 0 1 0 0;...
     0 1 0 0 0;...
     0 0 0 0 1;...
     0 0 0 1 0];
 %--------------------------------------------------------------------------
end

