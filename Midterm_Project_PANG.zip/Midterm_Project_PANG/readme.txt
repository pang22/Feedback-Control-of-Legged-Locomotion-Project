Open and run the setpath_bo.m to add files to folder to the current path.

1. To run the 20 step simulation and plot the result, run the simulate_plot_pang.m function.

2. To run the fmincon optimization, open the Motion_Planning folder, back up to the main folder,
and run the nonlinear_motion_planning_optimization.m file